package org.nucleus.utility.enums;

public enum FundBasedFlag {
    FUND_BASED
    ,
    NON_FUND_BASED
    ,
    BOTH
}
