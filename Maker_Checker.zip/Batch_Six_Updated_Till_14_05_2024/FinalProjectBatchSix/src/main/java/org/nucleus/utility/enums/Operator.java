package org.nucleus.utility.enums;

public enum Operator {
    EQUALSTO,
    GREATERTHAN,
    LESSTHAN,
    EQUALTO,
    GREATERTHANEQUALTO,
    LESSTHANEQUALTO
}
