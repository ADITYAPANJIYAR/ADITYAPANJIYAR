package org.nucleus.utility.enums;

public enum ReceiptStatus {
    UNREALISED,
    REALISED
}
