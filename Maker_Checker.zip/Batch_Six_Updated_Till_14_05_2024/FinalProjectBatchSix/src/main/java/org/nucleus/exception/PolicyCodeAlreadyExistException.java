package org.nucleus.exception;

public class PolicyCodeAlreadyExistException extends Exception{

    public PolicyCodeAlreadyExistException(String message)
    {
        super(message);
    }
}
