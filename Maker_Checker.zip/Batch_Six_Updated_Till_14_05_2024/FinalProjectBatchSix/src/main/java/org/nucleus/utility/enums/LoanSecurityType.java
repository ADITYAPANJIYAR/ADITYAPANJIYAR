package org.nucleus.utility.enums;

public enum LoanSecurityType {
    GOLD
    ,
    PROPERTY
    ,
    VEHICLE
    ,
    NONE
}
