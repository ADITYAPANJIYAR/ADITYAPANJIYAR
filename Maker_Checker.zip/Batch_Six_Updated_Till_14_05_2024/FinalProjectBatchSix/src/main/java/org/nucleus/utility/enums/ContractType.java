package org.nucleus.utility.enums;

public enum ContractType {
    LEASE , LOAN
}
