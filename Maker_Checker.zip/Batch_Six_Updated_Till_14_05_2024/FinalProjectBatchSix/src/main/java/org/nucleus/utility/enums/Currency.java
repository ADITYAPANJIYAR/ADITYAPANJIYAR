package org.nucleus.utility.enums;

public enum Currency {
    INR
}
