package entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.nucleus.dao.EligibilityPolicyCheckerDao;
import org.nucleus.dao.EligibilityPolicyMakerDAO;
import org.nucleus.dto.EligibilityPolicyTempDTO;
import org.nucleus.entity.meta.TempMetaData;
import org.nucleus.entity.temporary.EligibilityPolicyTemp;
import org.nucleus.service.EligibilityPolicyCheckerServiceImpl;
import org.nucleus.service.EligibilityPolicyMakerService;
import org.nucleus.utility.dtomapper.EligibilityPolicyTempDAOMapper;
import org.nucleus.utility.enums.RecordStatus;
import org.nucleus.utility.temptoperm.EligibilityMapper;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

class EligibilityPolicyCheckerServiceTest {

    @InjectMocks
    private EligibilityPolicyCheckerServiceImpl eligibilityPolicyCheckerService;

    @Mock
    private EligibilityPolicyCheckerDao checkerDaoMock;

    @Mock
    private EligibilityPolicyMakerService makerServiceMock;

    @Mock
    private EligibilityPolicyMakerDAO makerDAOMock;

    @Mock
    private EligibilityPolicyTempDAOMapper eligibilityPolicyTempDAOMapperMock;

    @Mock
    private EligibilityMapper eligibilityTempToPermMock;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testApproveEligibilityPolicy_NullInput() {
        assertFalse(eligibilityPolicyCheckerService.approveEligibilityPolicy(null));
    }

    @Test
    void testApproveEligibilityPolicy_Modification() {
        EligibilityPolicyTemp eligibilityPolicyTemp = new EligibilityPolicyTemp();
        eligibilityPolicyTemp.setMetaData(new TempMetaData());
        eligibilityPolicyTemp.getMetaData().setRecordStatus(RecordStatus.N);
        when(checkerDaoMock.getEligibilityPolicyByCode(anyString())).thenReturn(new EligibilityPolicyTempDTO());
        when(checkerDaoMock.updateEligibilityPolicy(any())).thenReturn(true);
        when(makerServiceMock.deleteEligibilityPolicy(anyLong(), isNull())).thenReturn(true);

        // Assertion
        assertFalse(eligibilityPolicyCheckerService.approveEligibilityPolicy(eligibilityPolicyTemp));
    }

    @Test
    void testRejectEligibilityPolicy_NullInput() {
        assertFalse(eligibilityPolicyCheckerService.rejectEligibilityPolicy(null));
    }

    @Test
    void testUpdateEligibilityPolicy_NullInput() {
        assertFalse(eligibilityPolicyCheckerService.updateEligibilityPolicy(null));
    }

    @Test
    void testUpdateEligibilityPolicy_NotNullInput() {
        assertTrue(eligibilityPolicyCheckerService.updateEligibilityPolicy(new EligibilityPolicyTemp()));
    }

    @Test
    void testGetEligibilityPolicy_NullInput(){
        assertNull(eligibilityPolicyCheckerService.getEligibilityPolicy(null));
    }

    @Test
    void testGetEligibilityPolicy_NotNullInput(){
        Long policyId = 123L;
        EligibilityPolicyTempDTO expectedDTO = new EligibilityPolicyTempDTO();
        when(eligibilityPolicyCheckerService.getEligibilityPolicy(policyId)).thenReturn(expectedDTO);
    }

    /*
        @Test
    public void testRejectEligibilityPolicy_N_Status() {
        // Setup
        EligibilityPolicyTempDTO eligibilityPolicyTemp = new EligibilityPolicyTempDTO();
        TempMetaData metaData = new TempMetaData();
        metaData.setRecordStatus(RecordStatus.N);
        eligibilityPolicyTemp.setMetaData(metaData);

        when(makerServiceMock.updateEligibilityPolicy(eligibilityPolicyTemp)).thenReturn(true);
        boolean result = eligibilityPolicyCheckerService.rejectEligibilityPolicy(eligibilityPolicyTemp);
        assertTrue(result);
    }
    @Test
    void testRejectEligibilityPolicy_NoStatus() {
        EligibilityPolicyTemp eligibilityPolicyTemp = new EligibilityPolicyTemp();
        boolean result = eligibilityPolicyCheckerService.rejectEligibilityPolicy(eligibilityPolicyTemp);
        assertFalse(result);
    }
    @Test
    void testApproveEligibilityPolicy_Deletion() {
        // Setup
        EligibilityPolicyTemp eligibilityPolicyTemp = new EligibilityPolicyTemp();
        eligibilityPolicyTemp.getMetaData().setRecordStatus(RecordStatus.D);

        // Mocking
//        when(checkerDaoMock.getEligibilityPolicyByCode(anyString())).thenReturn(new EligibilityPolicy());
        when(checkerDaoMock.deleteEligibilityPolicy(anyLong())).thenReturn(true);
        when(makerServiceMock.deleteEligibilityPolicy(anyLong(), isNull())).thenReturn(true);

        // Assertion
        assertTrue(eligibilityPolicyCheckerService.approveEligibilityPolicy(eligibilityPolicyTemp));
    }

    @Test
    void testApproveEligibilityPolicy_OtherStatus() {
        // Setup
        EligibilityPolicyTemp eligibilityPolicyTemp = new EligibilityPolicyTemp();
        eligibilityPolicyTemp.getMetaData().setRecordStatus(RecordStatus.N);

        // Mocking
        when(checkerDaoMock.approveEligibilityPolicy(any())).thenReturn(true);
        when(makerServiceMock.deleteEligibilityPolicy(anyLong(), isNull())).thenReturn(true);

        // Assertion
        assertTrue(eligibilityPolicyCheckerService.approveEligibilityPolicy(eligibilityPolicyTemp));
    }
     */

}

