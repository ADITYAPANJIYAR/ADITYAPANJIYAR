package org.nucleus.exception;

public class ChargeDefinitionCodeAlreadyExist extends Exception{
    public ChargeDefinitionCodeAlreadyExist(String message){
        super(message);
    }
}
