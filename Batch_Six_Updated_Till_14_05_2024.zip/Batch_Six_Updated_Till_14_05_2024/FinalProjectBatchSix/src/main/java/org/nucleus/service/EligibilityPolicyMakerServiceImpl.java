package org.nucleus.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.nucleus.dao.EligibilityPolicyMakerDAO;
import org.nucleus.dto.EligibilityPolicyTempDTO;
import org.nucleus.entity.temporary.EligibilityPolicyTemp;
import org.nucleus.utility.dtomapper.EligibilityPolicyTempDAOMapper;
import org.nucleus.utility.dtomapper.EligibilityPolicyTempDTOMapper;
import org.nucleus.utility.enums.RecordStatus;
import org.nucleus.utility.validations.EligibilityPolicyValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;

@Service
@Transactional
public class EligibilityPolicyMakerServiceImpl implements EligibilityPolicyMakerService {
    private static final Logger log = LogManager.getLogger(EligibilityPolicyMakerServiceImpl.class);
    private String nullString = "eligibilityPolicies is null";
    private EligibilityPolicyMakerDAO makerDAO;

    @Autowired
    public EligibilityPolicyMakerServiceImpl(EligibilityPolicyMakerDAO makerDAO) {
        this.makerDAO = makerDAO;
    }
    @Autowired
    private EligibilityPolicyValidator eligibilityPolicyValidations;
    @Autowired
    private EligibilityPolicyTempDTOMapper policyDTOMapper;
    @Autowired
    private EligibilityPolicyTempDAOMapper policyDAOMapper;
    @Autowired
    private EligibilityPolicyCheckerService eligibilityPolicyCheckerService;
    @Override
    public boolean insertEligibilityPolicy(EligibilityPolicyTempDTO eligibilityPoliciesDTO) {
        if (eligibilityPoliciesDTO == null) {
            log.info(nullString);
            return false;
        }
        if (eligibilityPolicyValidations.validate(eligibilityPoliciesDTO)) {
            log.error("Eligibility Policy Code already exists");
            return false;
        }
        return makerDAO.insertEligibilityPolicy(eligibilityPoliciesDTO);
    }

    @Override
    public boolean deleteEligibilityPolicy(Long policyId,String flag) {

        if (policyId == null) {
            log.info("Given policy code is null");
            return false;
        }
        else {
            if ("A".equalsIgnoreCase(flag)){
                EligibilityPolicyTempDTO eligibilityPolicyTempDTO=eligibilityPolicyCheckerService.getEligibilityPolicy(policyId);
                eligibilityPolicyTempDTO.setFlag(RecordStatus.D);
                return insertEligibilityPolicy(eligibilityPolicyTempDTO);
            }
            else if("D".equalsIgnoreCase(flag)){
                log.info("Ise delete nhi krna");
                return true;
            }else {
                return makerDAO.deleteEligibilityPolicy(policyId);
            }
        }
    }

    @Override
    public boolean deleteEligibilityPolicy(EligibilityPolicyTempDTO eligibilityPolicyTempDTO) {
        if (eligibilityPolicyTempDTO==null){
            log.info(nullString);
            return false;
        }
        else {
            return makerDAO.deleteEligibilityPolicy(eligibilityPolicyTempDTO);
        }
    }

    @Override
    public boolean deleteEligibilityPolicyById(Long policyId) {
        if (policyId==null)
            return false;
        return makerDAO.deleteEligibilityPolicyById(policyId);
    }

    @Override
    public boolean updateEligibilityPolicy(EligibilityPolicyTempDTO eligibilityPoliciesDTO) {

        if (eligibilityPoliciesDTO == null) {
            log.info(nullString);
            return false;
        }
        String flag= String.valueOf(eligibilityPoliciesDTO.getFlag());
        log.info(flag);
        if (flag.equalsIgnoreCase("A") && eligibilityPoliciesDTO.getFrom()!=null) {
            eligibilityPoliciesDTO.setFlag(RecordStatus.M);
            return insertEligibilityPolicy(eligibilityPoliciesDTO);
        }
        if (flag.equalsIgnoreCase("NR") && eligibilityPoliciesDTO.getFrom()!=null)
            eligibilityPoliciesDTO.setFlag(RecordStatus.N);
        else if(flag.equalsIgnoreCase("MR")&& eligibilityPoliciesDTO.getFrom()!=null){
            eligibilityPoliciesDTO.setFlag(RecordStatus.M);
        }
        log.info(eligibilityPoliciesDTO.getFlag());
        return makerDAO.updateEligibilityPolicy(eligibilityPoliciesDTO);

    }


    @Override
    public boolean updateEligibilityPolicy(Long policyId, String flag) {
        if (policyId==null)
            return false;
        EligibilityPolicyTempDTO eligibilityPoliciesDTO=getEligibilityPolicy(policyId);
        eligibilityPoliciesDTO.setFlag(RecordStatus.valueOf(flag));


        log.info("lkl");
        return makerDAO.updateEligibilityPolicy(eligibilityPoliciesDTO);
    }

    @Override
    public EligibilityPolicyTempDTO getEligibilityPolicy(Long policyId) {
            return makerDAO.getEligibilityPolicyDTO(policyId);
    }

    @Override
//    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public List<EligibilityPolicyTemp> viewAllEligibilityPolicy() {
        List<EligibilityPolicyTemp> list = makerDAO.viewAllEligibilityPolicy();
        if (list==null||list.isEmpty()) {
            log.info("List is empty");
            return Collections.emptyList();
        }
        return list;
    }
}
