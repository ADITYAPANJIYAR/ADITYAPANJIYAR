package org.nucleus.dto;

import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Component
public class StateDTO {
    private Integer id;

    @Pattern(regexp = "^[a-zA-Z0-9]+$", message = "No Special Character allowed")
    @NotNull(message = "State Code can't be Empty")
    private String stateCode;

    @NotNull(message = "State Name can't be Empty ")
    @Pattern(regexp = "^[A-Za-z]+$")
    private String stateName;

    private CountryDTO country;
    private String region;

    private Boolean isUnionTerritory;


    private TempMetaData metaDataTemp;
//    private MetaData metaData;

    public StateDTO()
    {
        this.metaDataTemp = new TempMetaData();
//        this.metaData = new MetaData();
        this.country = new CountryDTO();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public CountryDTO getCountry() {
        return country;
    }

    public void setCountry(CountryDTO country) {
        this.country = country;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public Boolean getUnionTerritory() {
        return isUnionTerritory;
    }

    public void setUnionTerritory(Boolean unionTerritory) {
        isUnionTerritory = unionTerritory;
    }

    public TempMetaData getMetaDataTemp() {
        return metaDataTemp;
    }


    public void setMetaDataTemp(TempMetaData metaDataTemp) {
        this.metaDataTemp = metaDataTemp;
    }

//    public MetaData getMetaData() {
//        return metaData;
//    }
//
//    public void setMetaData(MetaData metaData) {
//        this.metaData = metaData;
//    }

    @Override
    public String toString() {
        return "StateDTO{" +
                "id=" + id +
                ", stateCode='" + stateCode + '\'' +
                ", stateName='" + stateName + '\'' +
                ", country=" + country +
                ", region='" + region + '\'' +
                ", isUnionTerritory=" + isUnionTerritory +
                ", metaDataTemp=" + metaDataTemp +

                '}';
    }
}
