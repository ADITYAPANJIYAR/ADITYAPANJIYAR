package org.nucleus.service;

import javassist.NotFoundException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.nucleus.dao.*;
import org.nucleus.dto.ReceivablePayableDTO;
import org.nucleus.dto.RepayScheduleDTO;
import org.nucleus.utility.enums.ReceivablePayableStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.nucleus.dto.LoanAccountDTO;
import org.nucleus.dto.LoanClosureDTO;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.utility.enums.LoanStatus;
import org.nucleus.utility.enums.ClosureStatus;
import org.nucleus.utility.enums.RecordStatus;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
@Service
@Transactional
public class LoanClosureServiceTempImpl implements LoanClosureServiceTemp {
    private static final Logger logger= LogManager.getLogger(LoanClosureServiceTempImpl.class);
    @Autowired
    LoanAccountDAO loanAccountDAO;
    @Autowired
    LoanClosureDAOTemp loanClosureDAOTemp;
    @Autowired
    LoanClosureDAO loanClosureDAO;
    @Autowired
    RepayScheduleDAO repayScheduleDAO;
    @Autowired
    ReceivablePayableDao receivablePayableDao;

    private static final int MAX_THREADS =10;
    private static int batch_size =50;
    @Override
    public boolean performLoanClosure() {
//total number of rows in loan account table
        Long totalRecords = loanAccountDAO.getRowCount();
        if(totalRecords==0)
            return false;
        if(totalRecords<= batch_size)
            batch_size = 1;
//number of threads to be made.
        Integer numThreads = Integer.parseInt(String.valueOf(Math.min(MAX_THREADS, totalRecords / batch_size)));
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        IntStream.range(0, numThreads).forEach(element -> {
            executor.submit(() -> {
                try {
//getting the batches for performing loan closure
                    List<LoanAccountDTO> batch = loanAccountDAO.getLoanAccountsInBatch(element, batch_size);
                    closeLoanAccounts(batch);

                }
                catch (Exception e) {
                    Thread.currentThread().interrupt();
                }
                finally {
                    executor.shutdown();
                }
            });
        });
        return true;
    }
    @Override
    public void closeLoanAccounts(List<LoanAccountDTO> loanAccounts) {
        try {
            IntStream.range(0, loanAccounts.size())
                    .forEach((chunk) -> {
                        List<LoanClosureDTO> loanClosureDTOList=new ArrayList<>();
// Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
// String username = authentication.getName();
                        loanAccounts.forEach((loanAccountDTO) -> {
                            LoanClosureDTO loanClosureDTO = new LoanClosureDTO();
                            loanAccountDTO.setLoanStatus(LoanStatus.CLOSED);
                            loanClosureDTO.setLoanAccountDTO(loanAccountDTO);
                            loanClosureDTO.setLoanClosureDate(Date.valueOf(LocalDate.now()));
                            loanClosureDTO.setClosureStatus(ClosureStatus.REGULAR_CLOSURE);
                            MetaData metaData = new MetaData();
// metaData.setCreatedBy(username);
// metaData.setCreationDate(Date.valueOf(LocalDate.now()));
                            metaData.setRecordStatus(RecordStatus.N);
                            metaData.setCreationDate(Date.valueOf(LocalDate.now()));
                            loanClosureDTO.setMetaData(metaData);
                            loanClosureDTOList.add(loanClosureDTO);
                        });
                        loanAccountDAO.updateBatch(loanAccounts, loanAccounts.size());
                        loanClosureDAO.addData(loanClosureDTOList,loanAccounts.size());
                    });
        }
        catch (Exception e) {
            logger.error(e.getMessage());
            Thread.currentThread().interrupt();
        }
// finally {
// executor.shutdown();
// }
    }
    @Override
    public List<LoanAccountDTO> getLoanAccountsInBatch(int offset, int batchSize) {
        return loanAccountDAO.getLoanAccountsInBatch(offset,batchSize);
    }
    @Override
    public boolean addData(LoanClosureDTO loanClosureDTO) {
        return loanClosureDAOTemp.addData(loanClosureDTO);
    }
    @Override
    public boolean update(LoanClosureDTO loanClosureDTO) {
        return loanClosureDAOTemp.update(loanClosureDTO);
    }
    @Override
    public boolean delete(LoanClosureDTO loanClosureDTO) {
        return loanClosureDAOTemp.delete(loanClosureDTO);
    }
    @Override
    public boolean delete(Long loanClosureId) {
        return loanClosureDAOTemp.delete(loanClosureId);
    }
    @Override
    public List<LoanClosureDTO> getAllLoanClosureData() {
        return loanClosureDAO.getAllLoanClosureData();
    }
    @Override
    public LoanClosureDTO getLoanClosureDetail(Long loanClosureId) {
        return loanClosureDAOTemp.getLoanClosureDetail(loanClosureId);
    }
    @Override
    public boolean rejectLoanClosure(Long loanClosureId) throws NotFoundException {
// Retrieve the loan closure from the temporary table
        LoanClosureDTO loanClosureDTO = getLoanClosureDetail(loanClosureId);
        if (loanClosureDTO == null) {
            throw new NotFoundException("Loan closure not found in temporary table.");
        }
// Update the status of the loan closure to "New Rejected"
        MetaData metaData=new MetaData();
        metaData.setRecordStatus(RecordStatus.NR);
        loanClosureDTO.setMetaData(metaData);
// Save the updated loan closure
        loanClosureDAOTemp.update(loanClosureDTO);
        return true;
    }
    @Override
    public LoanClosureDTO getLoanClosureDetailPer(Long closureLoanId){
        return loanClosureDAO.getLoanClosureDetailPer(closureLoanId);
    }
    @Override
    public boolean deletePerm(LoanClosureDTO loanClosureDTO) {
        try {
// Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
// String username = authentication.getName();
//setting the value in temporary table with D status.
// loanClosureDTO.getMetaData().setModifiedBy(username);
            loanClosureDTO.getMetaData().setModifiedDate(Date.valueOf(LocalDate.now()));
            loanClosureDTO.getMetaData().setRecordStatus(RecordStatus.D);
            loanClosureDAOTemp.addData(loanClosureDTO);
            return true;
        }
        catch (Exception e){
            return false;
        }
    }
    @Override
    public boolean approveLoanClosure(Long loanClosureId) throws NotFoundException {
// Retrieve the loan closure from the temporary table
        LoanClosureDTO loanClosureTemp = getLoanClosureDetail(loanClosureId);
        if (loanClosureTemp == null) {
            throw new NotFoundException("Loan closure not found in temporary table.");
        }
// Create a corresponding permanent loan closure
        LoanClosureDTO loanClosureDTO = new LoanClosureDTO();
        loanClosureDTO.setLoanClosureId(loanClosureId);
        loanClosureDTO.setLoanAccountDTO(loanClosureTemp.getLoanAccountDTO());
        loanClosureDTO.setLoanClosureDate(loanClosureTemp.getLoanClosureDate());
        loanClosureDTO.setClosureStatus(loanClosureTemp.getClosureStatus());
        MetaData metaData = new MetaData();
        metaData.setRecordStatus(RecordStatus.A);
        loanClosureDTO.setMetaData(metaData);
// Save the permanent loan closure
        loanClosureDAO.save(loanClosureDTO);
// Delete the loan closure from the temporary table
        loanClosureDAOTemp.delete(loanClosureTemp);
        return true;
    }

    @Override
    public boolean approveDeletePer(Long loanClosureId) throws NotFoundException {
        LoanClosureDTO loanClosureTemp = getLoanClosureDetail(loanClosureId);
        if (loanClosureTemp == null) {
            throw new NotFoundException("Loan closure not found in temporary table.");
        }
        if(getLoanClosureDetailPer(loanClosureId)!=null) {
// Delete the permanent loan closure
            loanClosureDAO.delete(loanClosureId);
// Delete the loan closure from the temporary table
            loanClosureDAOTemp.delete(loanClosureTemp);
            return true;
        }
        return false;
    }
    @Override
    public boolean rejectDeletePerm (Long loanClosureId) throws NotFoundException{
        try {
            LoanClosureDTO loanClosureTemp = getLoanClosureDetail(loanClosureId);
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication.getName();
            if (loanClosureTemp == null) {
                throw new NotFoundException("Loan closure not found in temporary table.");
            }
            if (getLoanClosureDetailPer(loanClosureId)!=null) {
                loanClosureTemp.getMetaData().setRecordStatus(RecordStatus.DR);
                loanClosureTemp.getMetaData().setModifiedBy(username);
                loanClosureTemp.getMetaData().setModifiedDate(Date.valueOf(LocalDate.now()));
                loanClosureDAOTemp.update(loanClosureTemp);
            }
        }
        catch (Exception e){
            return false;
        }
        return false;
    }
    @Override
    public List<LoanClosureDTO> getCheckerTempData() {
        return loanClosureDAOTemp.getCheckerTempData();
    }
    @Override
    public List<LoanClosureDTO> getCheckerTempDataDeleted() {
        return loanClosureDAOTemp.getCheckerTempDataDeleted();
    }
    @Override
    public List<ReceivablePayableDTO> getLoansNotClosed() {
        AtomicReference<List<ReceivablePayableDTO>> receivablePayableDTOList = new AtomicReference<>();
        List<LoanAccountDTO> accountDTOList=loanAccountDAO.getAllLoanAccounts();
        accountDTOList.forEach((loanAccountDTO -> {
            List<RepayScheduleDTO> repayScheduleDTOS =repayScheduleDAO.fetchRepaySchedule(loanAccountDTO.getLoanAccountId());
            if(!repayScheduleDTOS.isEmpty() && Objects.equals(repayScheduleDTOS.get(repayScheduleDTOS.size()-1).getDueDate(), Date.valueOf(LocalDate.now())) &&
                    loanAccountDTO.getLoanAmountDisbursed()-loanAccountDTO.getLoanAmountPaidByCustomer()>=3.6
                    && loanAccountDTO.getLoanStatus().equals(LoanStatus.ACTIVE)){
                receivablePayableDTOList.set(receivablePayableDao.getReceivablePayableBYLoanAccId(loanAccountDTO.getLoanAccountId())
                        .stream()
                        .filter(receivablePayableDTO->receivablePayableDTO.getReceivablePayableStatus()
                                .equals(ReceivablePayableStatus.PENDING))
                        .collect(Collectors.toList())
                );
            }
        }));
        return receivablePayableDTOList.get();
    }
    @Override
    public List<LoanClosureDTO> getAllLoanClosureDataPermanentTable() {
        return loanClosureDAO.getAllLoanClosureDataPermanentTable();
    }
}