package org.nucleus.controller;

import org.nucleus.dto.ChargeDefinitionDTO;
import org.nucleus.dto.ChargePolicyDto;
import org.nucleus.dto.ChargePolicyParameterTempDto;
import org.nucleus.dto.ChargePolicyTempDto;
import org.nucleus.exception.PolicyCodeAlreadyExistException;
import org.nucleus.service.ChargeDefinitionService;
import org.nucleus.service.ChargePolicyService;
import org.nucleus.service.ChargePolicyTempService;
import org.nucleus.utility.enums.Operator;
import org.nucleus.utility.enums.RecordStatus;
import org.nucleus.utility.temptoperm.ChargePolicyConvertor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.validation.Valid;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("maker")
public class ChargePolicyMakerController {
    private ChargePolicyTempService chargePolicyTempService;
    private ChargePolicyService chargePolicyService;
    private ChargePolicyConvertor chargePolicyConvertor;
    private ChargeDefinitionService chargeDefinitionService ;

    public ChargePolicyMakerController(){}
    @Autowired
    public ChargePolicyMakerController(ChargeDefinitionService chargeDefinitionService,ChargePolicyConvertor chargePolicyConvertor,ChargePolicyService chargePolicyService,ChargePolicyTempService chargePolicyTempService)
    {
        this.chargePolicyService=chargePolicyService;
        this.chargeDefinitionService=chargeDefinitionService;
        this.chargePolicyConvertor=chargePolicyConvertor;
        this.chargePolicyTempService = chargePolicyTempService;
    }

    private String recordStatusBeforeUpdate;
    private String updateStatus = "false";


    @RequestMapping("charge-policy-table")
    public ModelAndView displayChargePolicies()
    {
        ModelAndView model = new ModelAndView();
// get all charge policy from the temporary table
        List<ChargePolicyTempDto> chargePoliciesTempDtoList = chargePolicyTempService.getAllChargePolicy();

// get all charge policy form permanent table
        List<ChargePolicyDto> chargePolicyDtoList = chargePolicyService.getAllChargePolicy();
        if(chargePolicyDtoList != null&&chargePoliciesTempDtoList!=null) {
// check the duplicate policy code
            chargePolicyDtoList = chargePolicyDtoList.stream()
                    .filter(policy -> chargePoliciesTempDtoList.stream()
                            .noneMatch(policyTemp -> policyTemp.getPolicyCode().equals(policy.getPolicyCode())))
                    .collect(Collectors.toList());
        }


// add charge policies of permanent table
        model.addObject("chargePoliciesPerm",chargePolicyDtoList);
// add charge policies of temporary table
        model.addObject("chargePolicies",chargePoliciesTempDtoList);
        model.setViewName("charge-policy");
        return model;
    }

    @GetMapping("getMakerDetails")
    public String getPolicyDetails(@RequestParam("code")String policyCode ,Model model)
    {
        ChargePolicyTempDto chargePolicy = chargePolicyTempService.getChargePolicy(policyCode);
        List<ChargeDefinitionDTO> chargeNameDtoList = chargeDefinitionService.fetchDetailsFromTheMasterTable();
        model.addAttribute("chargeList",chargeNameDtoList);
        if(chargePolicy==null)
        {
            ChargePolicyDto chargePolicyDto = chargePolicyService.getChargePolicy(policyCode);

            model.addAttribute("selectedPolicy",chargePolicyDto);
        }
        else
        {
            model.addAttribute("selectedPolicy", chargePolicy);
        }
        return "display-maker";
    }

    @GetMapping("charge-policy")
    public String createChargePolicy(Model model)
    {

//         charge list
        List<ChargeDefinitionDTO> chargeNameDtoList = chargeDefinitionService.fetchDetailsFromTheMasterTable();

//        operator list
        List<Operator> operatorList = Arrays.asList(Operator.values());

        model.addAttribute("operatorList",operatorList);
        model.addAttribute("charges",chargeNameDtoList);

//        check whether the policy code exist in the database or not
        ChargePolicyTempDto chargePolicyTempDtoFlag = chargePolicyTempService.getChargePolicyByEditFlag(true);

//        if policy code exist then autofill the details of that policy code in the form(in case of save and update)
        if(chargePolicyTempDtoFlag !=null)
        {
            model.addAttribute("chargePolicy", chargePolicyTempDtoFlag);
            List<ChargePolicyParameterTempDto> chargePolicyParameterTempDtos = chargePolicyTempDtoFlag.getChargePolicyParameterList();
            model.addAttribute("chargePolicyParameter",chargePolicyParameterTempDtos);
            model.addAttribute("edit","true");
        }

//        If policy code does not exist then add a new object in the model and view
        else
        {
            ChargePolicyTempDto chargePolicyTempDto = new ChargePolicyTempDto();
            model.addAttribute("chargePolicy", chargePolicyTempDto);
        }
        return "charge-policy-form";
    }

    @PostMapping("charge-policy")
    public String saveChargePolicy(@RequestParam("chargeCodes") List<String> chargeDefinitionCode,
                                         @RequestParam("operator") List<String> operator,
                                         @RequestParam("value") List<String> value,
                                         @RequestParam("action") String action,
                                         @ModelAttribute("chargePolicy")@Valid ChargePolicyTempDto chargePolicyTempDto, BindingResult errors,Model model)
    {

//      to get the username of maker
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        ModelAndView modelAndView = new ModelAndView();


        if(errors.hasErrors())
        {
            List<ChargeDefinitionDTO> chargeNameDtoList = chargeDefinitionService.fetchDetailsFromTheMasterTable();
            List<Operator> operatorList = Arrays.asList(Operator.values());


            model.addAttribute("operatorList",operatorList);
            model.addAttribute("charges",chargeNameDtoList);
            model.addAttribute("chargePolicy", chargePolicyTempDto);
            return "charge-policy-form";
            //return modelAndView;
        }

// create a list of ChargePolicyParameterDto objects
        List<ChargePolicyParameterTempDto> chargePolicyParametersDto = new ArrayList<>();

//        if update status is true (in case of save and update)
        if("true".equalsIgnoreCase(updateStatus))
        {
//           get the charge policy details for that policy code
            ChargePolicyTempDto chargePolicyTemp3 = chargePolicyTempService.getChargePolicy(chargePolicyTempDto.getPolicyCode());

//            set the creation date and created by
            chargePolicyTempDto.setCreationDate(chargePolicyTemp3.getCreationDate());
            chargePolicyTempDto.setCreatedBy(chargePolicyTemp3.getCreatedBy());

//            then delete that policy from the temporary table so that when we click on save and request, exception (PolicyCodeAlreadyExist) does not occur
            chargePolicyTempService.deleteChargePolicy(chargePolicyTempDto.getPolicyCode());
        }
        else {

//            If policy code does not exist then it means maker create a new policy so set new creation date and created by
            chargePolicyTempDto.setCreationDate(Date.valueOf(LocalDate.now()));
            chargePolicyTempDto.setCreatedBy(username);
        }

        for(int i=0;i<chargeDefinitionCode.size();i++)
        {
            ChargePolicyParameterTempDto chargePolicyParameterTempDto = new ChargePolicyParameterTempDto();

            chargePolicyParameterTempDto.setChargeDefinitionCode(chargeDefinitionCode.get(i));
            chargePolicyParameterTempDto.setOperator(Operator.valueOf(operator.get(i)));
            chargePolicyParameterTempDto.setValue(Double.parseDouble(value.get(i)));
            chargePolicyParametersDto.add(chargePolicyParameterTempDto);
        }
        chargePolicyTempDto.setChargePolicyParameterList(chargePolicyParametersDto);


//        if new rejected record is modified then set modified date and modified by
        if(("NR").equals(recordStatusBeforeUpdate))
        {
            chargePolicyTempDto.setModifiedDate(Date.valueOf(LocalDate.now()));
            chargePolicyTempDto.setModifiedBy(username);
        }


        if(recordStatusBeforeUpdate!=null)
        {
//           check record status and then set
            if(("N").equals(recordStatusBeforeUpdate) || ("NR").equals(recordStatusBeforeUpdate))
                chargePolicyTempDto.setRecordStatus(RecordStatus.N);
            else if(("M").equals(recordStatusBeforeUpdate) ||("MR").equals(recordStatusBeforeUpdate) || ("A").equals(recordStatusBeforeUpdate)||("DR").equals(recordStatusBeforeUpdate)||("D").equals(recordStatusBeforeUpdate))
                chargePolicyTempDto.setRecordStatus(RecordStatus.M);
        }
        else
        {
//            initially when maker create a new policy the value of recordStatusBeforeUpdate is null so set the recordStatus N
            chargePolicyTempDto.setRecordStatus(RecordStatus.N);
        }

        recordStatusBeforeUpdate=null;

        if("save".equalsIgnoreCase(action))
        {
            updateStatus="true";
            if(chargePolicyTempService.getChargePolicy(chargePolicyTempDto.getPolicyCode())!=null)
                chargePolicyTempService.deleteChargePolicy(chargePolicyTempDto.getPolicyCode());

            List<ChargeDefinitionDTO> chargeNameDtoList = chargeDefinitionService.fetchDetailsFromTheMasterTable();
            List<Operator> operatorList = Arrays.asList(Operator.values());
            model.addAttribute("operatorList",operatorList);
            model.addAttribute("charges",chargeNameDtoList);
            model.addAttribute("edit","true");

//          set the save flag to true
            chargePolicyTempDto.setSaveFlag(true);
            try
            {
                chargePolicyTempService.saveChargePolicy(chargePolicyTempDto);
                model.addAttribute("chargePolicy", chargePolicyTempDto);
                List<ChargePolicyParameterTempDto> chargePolicyParameterTempDtos = chargePolicyTempDto.getChargePolicyParameterList();
                model.addAttribute("chargePolicyParameter",chargePolicyParameterTempDtos);
                return "charge-policy-form";
            }
            catch(PolicyCodeAlreadyExistException e)
            {
                model.addAttribute("chargePolicy", chargePolicyTempDto);
                model.addAttribute("errorMessage",e.getMessage());
                return "charge-policy-form";
            }
            catch(Exception e)
            {
                model.addAttribute("errorMessage","Error occurred");
                return "error";
            }
        }
        else if("saveAndRequest".equalsIgnoreCase(action))
        {

//            set the saveFlag to false

            System.out.println("charge policy dto = " + chargePolicyTempDto);
            chargePolicyTempDto.setSaveFlag(false);
            try
            {
                if("M".equalsIgnoreCase(chargePolicyTempDto.getRecordStatus().toString()))
                {
//                    set the modified date when recordStatus set to M
                    chargePolicyTempDto.setModifiedDate(Date.valueOf(LocalDate.now()));
                    chargePolicyTempDto.setModifiedBy(username);
                }

//                 check unique constraint in the permanent
//                 table
                if("false".equalsIgnoreCase(updateStatus) && chargePolicyService.getChargePolicy(chargePolicyTempDto.getPolicyCode())!=null)
                    throw new PolicyCodeAlreadyExistException("This Policy code already approved");

                chargePolicyTempService.saveChargePolicy(chargePolicyTempDto);
            }
            catch(PolicyCodeAlreadyExistException e)
            {
                List<ChargeDefinitionDTO> chargeNameDtoList = chargeDefinitionService.fetchDetailsFromTheMasterTable();

                List<Operator> operatorList = Arrays.asList(Operator.values());
                model.addAttribute("operatorList",operatorList);
                model.addAttribute("chargePolicy", chargePolicyTempDto);
                model.addAttribute("charges",chargeNameDtoList);
                model.addAttribute("errorMessage",e.getMessage());
                return "charge-policy-form";
            }
            catch(Exception e)
            {
                e.printStackTrace();
                model.addAttribute("errorMessage","Error occurred");
                return "error";
            }

//            set the update status again to false
            if("true".equalsIgnoreCase(updateStatus))
                updateStatus = "false";
        }

        return "redirect:charge-policy-table";
    }



    // controller to delete charge policy
    @RequestMapping("delete-charge-policy")
    public ModelAndView deleteChargePolicy(@RequestParam("policyCode") String policyCode,
                                           @RequestParam("record") String recordStatus)
    {
        ModelAndView model = new ModelAndView();
        ChargePolicyTempDto chargePolicyTempDtoDel;
        ChargePolicyDto chargePolicyDtoDel ;

//        if recordStatus is A means we try to delete the authorised record
        if("A".equalsIgnoreCase(recordStatus))
        {
//            then change the recordStatus from A to D
            chargePolicyDtoDel = chargePolicyService.getChargePolicy(policyCode);

            chargePolicyDtoDel.setRecordStatus(RecordStatus.D);

            chargePolicyTempDtoDel = chargePolicyConvertor.permDtoToTempDto(chargePolicyDtoDel);
            chargePolicyTempDtoDel.setSaveFlag(false);
            try
            {
                chargePolicyTempService.saveChargePolicy(chargePolicyTempDtoDel);
            }
            catch(PolicyCodeAlreadyExistException e)
            {
                model.addObject("errorMessage",e.getMessage());
            }
            catch(Exception e)
            {
                model.setViewName("error");
                model.addObject("errorMessage","Error occurred");
            }
        }
        else {
//            If recordStatus is not A then simply delete that policy
            chargePolicyTempService.deleteChargePolicy(policyCode);
        }

        List<ChargePolicyTempDto> chargePoliciesTempDtoList = chargePolicyTempService.getAllChargePolicy();

//      get all charge policy form permanent table
        List<ChargePolicyDto> chargePolicyDtoList = chargePolicyService.getAllChargePolicy();

        if(chargePolicyDtoList != null){

//      check the duplicate policy code
        chargePolicyDtoList = chargePolicyDtoList.stream()
                .filter(policyTemp->chargePoliciesTempDtoList.stream()
                        .noneMatch(policy->policy.getPolicyCode().equals(policyTemp.getPolicyCode())))
                .collect(Collectors.toList());
        }


// add charge policies of permanent table
        model.addObject("chargePoliciesPerm",chargePolicyDtoList);
// add charge policies of temporary table
        model.addObject("chargePolicies",chargePoliciesTempDtoList);
        model.setViewName("charge-policy");
        return model;
    }
    // controller to update charge policy
    @RequestMapping("edit-charge-policy-form")
    public ModelAndView editChargePolicy(@RequestParam("policy") String policyCode,
                                         @RequestParam("record") String recordStatus)
    {
        ModelAndView model = new ModelAndView();

// set the update status
        updateStatus="true";
        ChargePolicyTempDto chargePolicyTempDto;
        ChargePolicyDto chargePolicyDto ;

        if("A".equalsIgnoreCase(recordStatus))
        {
            chargePolicyDto = chargePolicyService.getChargePolicy(policyCode);
            chargePolicyTempDto = chargePolicyConvertor.permDtoToTempDto(chargePolicyDto);
            try
            {
                chargePolicyTempService.saveChargePolicy(chargePolicyTempDto);
            }
            catch(PolicyCodeAlreadyExistException e)
            {
                model.addObject("errorMessage",e.getMessage());
            }
            catch(Exception e)
            {
                model.setViewName("error");
                model.addObject("errorMessage",e.getMessage() + "Error occurred");
            }
        }
        else
        {
            chargePolicyTempDto = chargePolicyTempService.getChargePolicy(policyCode);
        }



// store the record status
        recordStatusBeforeUpdate = chargePolicyTempDto.getRecordStatus().toString();

        model.addObject("chargePolicy", chargePolicyTempDto);
        List<ChargePolicyParameterTempDto> chargePolicyParameterTempDtos = chargePolicyTempDto.getChargePolicyParameterList();
        model.addObject("chargePolicyParameter",chargePolicyParameterTempDtos);
        List<ChargeDefinitionDTO> chargeNameDtoList = chargeDefinitionService.fetchDetailsFromTheMasterTable();

        List<Operator> operatorList = Arrays.asList(Operator.values());
        model.addObject("operatorList",operatorList);
        model.addObject("charges",chargeNameDtoList);
        model.addObject("edit","true");
        model.setViewName("charge-policy-form");
        return model;
    }

}