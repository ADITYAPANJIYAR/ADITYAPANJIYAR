package org.nucleus.controller;

import javassist.NotFoundException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.nucleus.service.LoanClosureServiceTemp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
//@PreAuthorize("hasRole('CHECKER')")
@RequestMapping("/checker")
public class ClosureCheckerController {
    private static final Logger logger= LogManager.getLogger(ClosureCheckerController.class);
    @Autowired
    LoanClosureServiceTemp temp;
    @RequestMapping("regular-closure")
    public ModelAndView referJsp(){
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.addObject("loanClosurePerList",temp.getAllLoanClosureDataPermanentTable());
        modelAndView.addObject("loanClosureTempList",temp.getAllLoanClosureData());
        modelAndView.setViewName("closure-check-datatable");
        return modelAndView;
    }

    @RequestMapping("approveLoanClosure/{loanClosureId}")
    public String approveRegularLoan(@PathVariable("loanClosureId") Long loanClosureId){
        try {
            temp.approveLoanClosure(loanClosureId);
            return "redirect:/regular-closure";
        } catch (NotFoundException e) {
            logger.error(e);
        }
        return null;
    }

    @RequestMapping("rejectLoanClosure/{loanClosureId}")
    public String rejectRegularLoan(@PathVariable("loanClosureId") Long loanClosureId){
        try {
            temp.rejectLoanClosure(loanClosureId);
            return "redirect:/regular-closure";
        } catch (NotFoundException e) {
            logger.error(e);
        }
        return null;
    }

}
