package org.nucleus.service.address;

import org.nucleus.dao.address.StateDAO;
import org.nucleus.dto.StateDTO;
import org.nucleus.entity.temporary.StateTemp;
import org.nucleus.utility.enums.RecordStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class StateServiceImpl implements StateService{

    private StateDAO stateDAO;


    @Autowired
    private StateTempService stateTempService;

    @Autowired
    public StateServiceImpl(StateDAO stateDAO){

        this.stateDAO=stateDAO;

    }

    @Override
    public boolean saveState(StateDTO stateDTO){

        return stateDAO.saveState(stateDTO);
    }

    @Override
    public List<StateDTO> getAllPendingStates() {
        return stateDAO.getAllPendingStates();
    }





    @Override
    public StateDTO convertToPermanentEntity(StateDTO stateDTO)
    {
        return stateDAO.convertToPermanentEntity(stateDTO);
    }

    @Override
    public List<StateDTO> getAllStates() {
        return stateDAO.getAllStates();
    }

    @Override
    public StateDTO getStateDtoById(Integer id) {
        return stateDAO.getStateDtoById(id);
    }

    @Override
    public void editApprovedStateAndRequestApproval(StateDTO stateDTO) {
        editApprovedStateAndRequestApproval(stateDTO);
    }
    @Override
    public List<StateDTO> getAllStatesWithApprovedStatus(){
        return stateDAO.getAllStatesWithApprovedStatus();
    }

    @Override
    public List<StateDTO> getStatesByCountryName(String countryName){
        return stateDAO.getStatesByCountryName(countryName);
    }

    @Override
    public StateDTO getStateByStateName(String stateName){
        return stateDAO.getStateByStateName(stateName);
    }

    @Override
    public boolean deleteState(Integer id){
        return  stateDAO.deleteState(id);
    }

    @Override
    public boolean approveState(StateDTO stateDTO){



//        stateDTO.getMetaData().setRecordStatus(RecordStatus.A);
        System.out.println("StateDTo inside approveStatus"+stateDTO);
        if(RecordStatus.D.equals(stateDTO.getMetaDataTemp().getRecordStatus()))
        {
            stateDAO.deleteState(stateDTO.getId());
            stateTempService.deleteState(stateDTO.getId());
            return true;
        }
        if(stateDAO.saveState(stateDTO)){
            System.out.println(stateDTO.getId());

           return stateTempService.deleteState(stateDTO.getId());

        }
        return false;
    }
}
