package org.nucleus.dao;



import org.nucleus.dto.LoanAccountDTO;
import org.nucleus.dto.LoanClosureDTO;

import java.util.List;

public interface LoanClosureDAOTemp {
    List<LoanAccountDTO> getLoanAccountsInBatch(int offset, int batchSize);
    boolean addData(LoanClosureDTO loanClosureDTO);

    boolean addData(List<LoanClosureDTO> loanClosureDTOList, int batchsize);

    boolean update(LoanClosureDTO loanClosureDTO);

    boolean delete(LoanClosureDTO loanClosureDTO);

    boolean delete(Long  loanClosureId);

    List<LoanClosureDTO> getAllLoanClosureData();

    LoanClosureDTO getLoanClosureDetail(Long loanClosureId);

    boolean updateBatch(List<LoanAccountDTO> chunk, int batchSize);

    List<LoanClosureDTO> getCheckerTempData();

    List<LoanClosureDTO> getCheckerTempDataDeleted();
    LoanClosureDTO findLoanClosureByLoanAccountId(Long loanAccountId);

    Long addEarlyClosureData(LoanClosureDTO loanClosureDTO);


}
