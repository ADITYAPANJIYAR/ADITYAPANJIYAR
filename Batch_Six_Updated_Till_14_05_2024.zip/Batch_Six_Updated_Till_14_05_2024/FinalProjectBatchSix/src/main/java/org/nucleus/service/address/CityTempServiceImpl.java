package org.nucleus.service.address;

import org.nucleus.dao.address.CityTempDAO;
import org.nucleus.dto.CityDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@Transactional
public class CityTempServiceImpl implements CityTempService {
    @Autowired
    private CityTempDAO cityTempDao;


    @Override
    public boolean saveCity(CityDTO cityDTO) {
        return cityTempDao.saveCity(cityDTO);
    }

    @Override
    public boolean updateCity(CityDTO cityDTO) {
        return cityTempDao.updateCity(cityDTO);
    }

    @Override
    public boolean deleteCity(Integer id) {
        return cityTempDao.deleteCity(id);
    }

    @Override
    public CityDTO getCityById(Integer id) {
        return cityTempDao.getCityById(id);
    }

    @Override
    public List<CityDTO> getAllCities() {
        return cityTempDao.getAllCities();
    }

    @Override
    public List<CityDTO> getPendingCities() {
        return cityTempDao.getPendingCities();
    }

    @Override
    public CityDTO getCityWithSaveFlag() {
        return cityTempDao.getCityWithSaveFlag();
    }

    @Override
    public CityDTO getCityByName(String cityName){
        return cityTempDao.getCityByName(cityName);
    }
}
