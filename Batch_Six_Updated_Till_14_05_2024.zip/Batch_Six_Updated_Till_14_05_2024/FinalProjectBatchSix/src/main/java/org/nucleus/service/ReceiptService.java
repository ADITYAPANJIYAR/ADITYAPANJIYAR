package org.nucleus.service;



import org.nucleus.dto.ReceiptDTO;

import java.sql.Date;
import java.util.List;

public interface ReceiptService {
    boolean createReceiptDTO(ReceiptDTO receiptDTO);
    ReceiptDTO getReceiptDTOById(Long id);
    List<ReceiptDTO> getAllReceiptDTOs();
    boolean updateReceiptDTO(ReceiptDTO updatedReceiptDTO);
    boolean deleteReceiptDTO(ReceiptDTO receiptDTO);
    List<ReceiptDTO> getallReceiptbyLoanACC(String id, Date fromdate, Date todate);
}
