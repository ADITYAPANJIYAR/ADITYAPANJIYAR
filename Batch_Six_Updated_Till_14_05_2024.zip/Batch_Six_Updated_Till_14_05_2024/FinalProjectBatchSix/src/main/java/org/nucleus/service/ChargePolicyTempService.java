package org.nucleus.service;


import org.nucleus.dto.ChargePolicyTempDto;
import org.nucleus.exception.PolicyCodeAlreadyExistException;

import java.util.List;


public interface ChargePolicyTempService {

    boolean saveChargePolicy(ChargePolicyTempDto chargePolicyTempDto) throws PolicyCodeAlreadyExistException;

    boolean updateChargePolicy(ChargePolicyTempDto chargePolicyTempDto);

    ChargePolicyTempDto getChargePolicy(String policyCode);

    boolean deleteChargePolicy(String policyCode);

    List<ChargePolicyTempDto> getAllChargePolicy();

    ChargePolicyTempDto getChargePolicyByEditFlag(Boolean flagForEdit);

}
