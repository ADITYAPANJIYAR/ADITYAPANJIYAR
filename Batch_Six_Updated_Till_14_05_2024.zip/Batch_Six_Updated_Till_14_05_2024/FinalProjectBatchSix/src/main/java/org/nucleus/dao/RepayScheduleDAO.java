package org.nucleus.dao;


import org.nucleus.dto.RepayScheduleDTO;
import org.nucleus.entity.permanent.RepaySchedule;

import java.util.List;

public interface RepayScheduleDAO {

    void insert(List<RepaySchedule> repaySchedule);
    List<RepayScheduleDTO> fetchRepaySchedule(Long loanId);
}
