package org.nucleus.service;
import javassist.NotFoundException;
import org.nucleus.dto.LoanAccountDTO;
import org.nucleus.dto.LoanClosureDTO;
import org.nucleus.dto.ReceivablePayableDTO;
import java.util.List;
public interface LoanClosureServiceTemp {
    void closeLoanAccounts(List<LoanAccountDTO> loanAccountDTOList);
    List<LoanAccountDTO> getLoanAccountsInBatch(int offset, int batchSize);
    boolean performLoanClosure();
    boolean addData(LoanClosureDTO loanClosureDTO);
    boolean update(LoanClosureDTO loanClosureDTO);
    boolean delete(LoanClosureDTO loanClosureDTO);
    boolean delete(Long loanClosureId);
    List<LoanClosureDTO> getAllLoanClosureData();
    LoanClosureDTO getLoanClosureDetail(Long loanClosureId);
    boolean rejectLoanClosure(Long loanClosureId) throws NotFoundException;
    boolean approveLoanClosure(Long loanClosureId) throws NotFoundException;
    List<LoanClosureDTO> getAllLoanClosureDataPermanentTable();
    LoanClosureDTO getLoanClosureDetailPer(Long closureLoanId);
    boolean deletePerm(LoanClosureDTO loanClosureDTO);
    boolean approveDeletePer(Long loanClosureId) throws NotFoundException;
    boolean rejectDeletePerm (Long loanClosureId) throws NotFoundException;
    List<LoanClosureDTO> getCheckerTempData();
    List<LoanClosureDTO> getCheckerTempDataDeleted();
    List<ReceivablePayableDTO> getLoansNotClosed();

}