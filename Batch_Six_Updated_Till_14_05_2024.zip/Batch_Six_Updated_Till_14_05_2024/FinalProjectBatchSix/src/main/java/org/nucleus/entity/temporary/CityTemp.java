package org.nucleus.entity.temporary;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;
import org.nucleus.entity.permanent.State;

import javax.persistence.*;

@Data
@Entity
@Table(name = "CITY_TEMP_TBL_BATCH_6")
@TableGenerator(name="ID_TEMP_TABLE_GEN_BATCH_6",pkColumnValue = "CITY_TEMP_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class CityTemp {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TEMP_TABLE_GEN_BATCH_6")
    private Integer cityId;
    @ManyToOne
    @JoinColumn(name="id")
    private State state;
    private String cityName;
    private String cityCode;
    private String stdCode;
    private String cityMICRCode;
    private String locationType;
    @Embedded
    private TempMetaData metaData;
    public CityTemp(){
        metaData = new TempMetaData();
    }
}
