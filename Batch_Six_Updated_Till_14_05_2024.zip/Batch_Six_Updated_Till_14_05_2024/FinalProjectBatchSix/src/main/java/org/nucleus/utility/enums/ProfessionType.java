package org.nucleus.utility.enums;

public enum ProfessionType {
    SALARIED, SELF_EMPLOYED
}
