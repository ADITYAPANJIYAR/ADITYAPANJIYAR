package org.nucleus.dao;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.nucleus.entity.permanent.LoanClosure;
import org.nucleus.dto.LoanClosureDTO;
import org.nucleus.entity.temporary.LoanClosureTemp;
import org.nucleus.utility.dtomapper.LoanClosureMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;
@Repository
@Transactional
public class LoanClosureDAOImpl implements LoanClosureDAO{
    private static final Logger logger= LogManager.getLogger(LoanClosureDAOTempImpl.class);
    @Autowired
    SessionFactory sessionFactory;
    Session session;
    @Override
    public boolean save(LoanClosureDTO loanClosureDTO) {
        try {
            session = sessionFactory.getCurrentSession();
            session.save(LoanClosureMapper.toEntityPer(loanClosureDTO));
            return true;
        }
        catch (HibernateException e){
            logger.error(e);
        }
        return false;
    }
    @Override
    public boolean addData(List<LoanClosureDTO> loanClosureDTOList, int batchSize) {
        try {
            Session session = sessionFactory.getCurrentSession();
            for (int i = 0; i < loanClosureDTOList.size(); i++) {
                LoanClosureDTO loanClosureDTO = loanClosureDTOList.get(i);
                LoanClosure loanClosure = LoanClosureMapper.toEntityPer(loanClosureDTO); // Convert DTO to Entity
                session.save(loanClosure); // Queue the update operation
            }
            return true;
        }
        catch (HibernateException e){
            logger.error(e);
        }
        return false;
    }
    @Override
    public List<LoanClosureDTO> getAllLoanClosureData() {
        try {
            session = sessionFactory.getCurrentSession();
            List<LoanClosure> loanClosureTemps = session.createQuery("From LoanClosure where closureStatus='REGULAR_CLOSURE'").getResultList();
            return loanClosureTemps.stream()
                    .map(LoanClosureMapper::toDTOPer)
                    .collect(Collectors.toList());
        }
        catch (HibernateException e){
            logger.error(e);
        }
        return null;
    }
    @Override
    public boolean update(LoanClosureDTO loanClosureDTO) {
        try {
            session = sessionFactory.getCurrentSession();
            session.update(LoanClosureMapper.toEntityPer(loanClosureDTO));
            return true;
        }
        catch (HibernateException e){
            logger.error(e);
        }
        return false;
    }
    @Override
    public boolean delete(Long closureLoanId) {
        try {
            session = sessionFactory.getCurrentSession();
            LoanClosureDTO loanClosureDTO=LoanClosureMapper.toDTOPer(session.get(LoanClosure.class, closureLoanId));
            loanClosureDTO.setLoanAccountDTO(null);
            session.delete(LoanClosureMapper.toEntityPer(loanClosureDTO));
            return true;
        }
        catch (HibernateException e){
            logger.error(e);
        }
        return false;
    }
    @Override
    public boolean delete(LoanClosureDTO loanClosureDTO) {
        try {
            session = sessionFactory.getCurrentSession();
            loanClosureDTO.setLoanAccountDTO(null);
            session.delete(LoanClosureMapper.toEntityTemp(loanClosureDTO));
            return true;
        }
        catch (HibernateException e){
            logger.error(e);
        }
        return false;
    }
    @Override
    public List<LoanClosureDTO> getAllLoanClosureDataPermanentTable() {
        try {
            session = sessionFactory.getCurrentSession();
            List<LoanClosure> loanClosurePer = session.createQuery("From LoanClosure").getResultList();
            return loanClosurePer.stream()
                    .map(LoanClosureMapper::toDTOPer)
                    .collect(Collectors.toList());
        }
        catch (HibernateException e) {
            logger.error(e);
        }
        return null;
    }
    @Override
    @Transactional(propagation= Propagation.REQUIRES_NEW)
    public LoanClosureDTO getLoanClosureDetailPer(Long closureLoanId) {
        try {
            session = sessionFactory.getCurrentSession();
            return LoanClosureMapper.toDTOPer(session.get(LoanClosure.class, closureLoanId));
        }
        catch (HibernateException e){
            logger.error(e);
        }
        return null;
    }
}