package org.nucleus.service;

import org.nucleus.dao.ChargePolicyTempDao;
import org.nucleus.dto.ChargePolicyTempDto;
import org.nucleus.exception.PolicyCodeAlreadyExistException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChargePolicyTempServiceImpl implements ChargePolicyTempService {


    @Autowired
    private ChargePolicyTempDao chargePolicyDao;

    public ChargePolicyTempServiceImpl()
    {

    }
    @Override
    public boolean saveChargePolicy(ChargePolicyTempDto chargePolicyTempDto) throws PolicyCodeAlreadyExistException {
            if(chargePolicyTempDto !=null)
            {
                return chargePolicyDao.saveChargePolicy(chargePolicyTempDto);
            }
            return false;
        }

    @Override
    public boolean updateChargePolicy(ChargePolicyTempDto chargePolicyTempDto) {
        return chargePolicyDao.updateChargePolicy(chargePolicyTempDto);
    }

    @Override
    public ChargePolicyTempDto getChargePolicy(String policyCode) {
        return chargePolicyDao.getChargePolicy(policyCode);
    }

    @Override
    public boolean deleteChargePolicy(String policyCode) {
        return chargePolicyDao.deleteChargePolicy(policyCode);
    }

    @Override
    public List<ChargePolicyTempDto> getAllChargePolicy() {
        return chargePolicyDao.getAllChargePolicy();
    }

    @Override
    public ChargePolicyTempDto getChargePolicyByEditFlag(Boolean flagForEdit) {
        return chargePolicyDao.getChargePolicyByEditFlag(flagForEdit);
    }
}

