package org.nucleus.service;

import org.nucleus.dao.ChargePolicyDao;
import org.nucleus.dto.ChargePolicyDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class ChargePolicyServiceImpl implements ChargePolicyService {


    @Autowired
    private ChargePolicyDao chargePolicyDao;

    public ChargePolicyServiceImpl()
    {

    }
    @Override
    public boolean saveChargePolicy(ChargePolicyDto chargePolicyDto){
            if(chargePolicyDto !=null)
            {
                System.out.println("Inside Service Method");
                return chargePolicyDao.saveChargePolicy(chargePolicyDto);
            }
            return false;
        }

    @Override
    public boolean editChargePolicy(ChargePolicyDto chargePolicyDto) {
        return chargePolicyDao.editChargePolicy(chargePolicyDto);
    }

    @Override
    public ChargePolicyDto getChargePolicy(String policyCode) {
        return chargePolicyDao.getChargePolicy(policyCode);
    }

    @Override
    public boolean deleteChargePolicy(String policyCode) {
        return chargePolicyDao.deleteChargePolicy(policyCode);
    }

    @Override
    public List<ChargePolicyDto> getAllChargePolicy() {
        return chargePolicyDao.getAllChargePolicy();
    }

}

