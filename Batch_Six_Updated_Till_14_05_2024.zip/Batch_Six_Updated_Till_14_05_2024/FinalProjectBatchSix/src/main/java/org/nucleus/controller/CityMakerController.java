package org.nucleus.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.nucleus.dto.CityDTO;
import org.nucleus.dto.CountryDTO;
import org.nucleus.dto.StateDTO;
import org.nucleus.entity.meta.TempMetaData;
import org.nucleus.service.address.CityService;
import org.nucleus.service.address.CityTempService;
import org.nucleus.service.address.CountryService;
import org.nucleus.service.address.StateService;
import org.nucleus.utility.enums.RecordStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

//Unzala
@Controller
@RequestMapping("maker/")
@PreAuthorize("hasRole('MAKER')")
public class CityMakerController {
    @Autowired
    private CityTempService cityTempService;

    @Autowired
    private CityService cityService;
    @Autowired
    private CountryService countryService;
    @Autowired
    private StateService stateService;

/*
    @ModelAttribute("states")

    public List<StateDTO> getStates(){

        return stateService.getStatesByCountryName("India");
    }*/

    @GetMapping(value = "/getStates", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<String> getStatesByCountry(@RequestParam("countryName") String countryName) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonData = objectMapper.writeValueAsString(stateService.getStatesByCountryName(countryName));

        return ResponseEntity.ok(jsonData);
    }

    @ModelAttribute("countries")
    public List<CountryDTO> getCountries(Model model){
        List<CountryDTO> countryDTOS= countryService.getCountryWithApprovedStatus();
        return countryDTOS;
    }


    @GetMapping("city-form")
    public ModelAndView showCityForm(){
        CityDTO cityDTO = new CityDTO();
        ModelAndView modelAndView=new ModelAndView();
        modelAndView.addObject("cityDTO", cityDTO);
        modelAndView.setViewName("city-form");
        return modelAndView;
    }

    @PostMapping("new-city")
    public ModelAndView saveCity(@ModelAttribute("cityDTO") CityDTO cityDto, @RequestParam(value = "action") String action ){
        ModelAndView mv = new ModelAndView();


        TempMetaData tempMetaData = new TempMetaData();
        CityDTO existingCity = cityTempService.getCityByName(cityDto.getCityName());

        if (action != null){
            switch(action){
                case "save":
                    tempMetaData = new TempMetaData();
                    tempMetaData.setSaveFlag(true);
                    tempMetaData.setRecordStatus(RecordStatus.N);

                    try{
                        if(existingCity==null){
                            cityDto.setMetaData(tempMetaData);
                            cityTempService.saveCity(cityDto);
                            mv.addObject("message", "City saved successfully");
                            mv.setViewName("city-form");
                        }

                    }
                    catch (Exception e){
                        mv.addObject("message" , "City couldn't be saved");
                        e.printStackTrace();

                    }
                    break;
                case "saveAndRequest":
                    if(existingCity==null){
                        try{
                            tempMetaData.setSaveFlag(false);
                            tempMetaData.setRecordStatus(RecordStatus.N);
                            cityDto.setMetaData(tempMetaData);
                            cityTempService.saveCity(cityDto);
                            mv.addObject("message", "City saved successfully and request sent for approval");
                            mv.setViewName("city-form");
                        }
                        catch (Exception e){
                            mv.addObject("message" ,"City couldn't be saved" );
                            mv.setViewName("city-form");
                            e.printStackTrace();
                        }
                    }
                    else{
                        mv.addObject("message", "City exists already");
                        mv.setViewName("city-form");
                    }
                    break;
                case "cancel":
                    mv.setViewName("redirect:/maker/city-form");
                    break;
                default:
                    break;

            }
        }
        return mv;

    }

    @GetMapping("show-city-list")
    public String displayCitiesList(Model model ){

        List<CityDTO> cityTemps = cityTempService.getAllCities();
        List<CityDTO> cityPerms = cityService.getAllCities();

        model.addAttribute("cityTemps" , cityTemps);
        model.addAttribute("cityPerms", cityPerms);

        return "maker-city-list";


    }

    @PostMapping("deleteCity/{id}")
    public ModelAndView deleteCity(@PathVariable("id") Integer id) {

        ModelAndView mv = new ModelAndView();
        CityDTO tempCity = cityTempService.getCityById(id);
        CityDTO permCity = cityService.getCityById(id);
        if (permCity == null) {
            cityTempService.deleteCity(id);
            mv.addObject("message", "City deleted");
        }
        if (tempCity == null) {
            permCity.getMetaData().setRecordStatus(RecordStatus.D);
            permCity.getMetaData().setSaveFlag(false);
            if (cityTempService.getCityByName(permCity.getCityName()) == null) {
                cityTempService.saveCity(permCity);
                mv.addObject("message", "Request sent to approve the deletion ");
            } else {
                mv.addObject("message", "Duplicate Request: Request has already been sent.");
            }


        }
        mv.setViewName("redirect:/maker/show-city-list");
        return mv;


    }




}
