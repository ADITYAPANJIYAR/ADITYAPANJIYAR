package org.nucleus.service;

import org.nucleus.dao.ReceiptDAO;
import org.nucleus.dto.ReceiptDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.util.List;
@Service
@Transactional
public class ReceiptServiceImpl implements ReceiptService {
    @Autowired
    ReceiptDAO receiptDAO;
    @Override
    public boolean createReceiptDTO(ReceiptDTO receiptDTO) {
        return receiptDAO.createReceipt(receiptDTO);
    }

    @Override
    public ReceiptDTO getReceiptDTOById(Long id) {
        return receiptDAO.getReceiptById(id);
    }

    @Override
    public List<ReceiptDTO> getAllReceiptDTOs() {
        return receiptDAO.getAllReceipts();
    }

    @Override
    public boolean updateReceiptDTO(ReceiptDTO updatedReceiptDTO) {
        return receiptDAO.updateReceipt(updatedReceiptDTO);
    }
    @Override
    public boolean deleteReceiptDTO(ReceiptDTO receiptDTO) {
        return receiptDAO.deleteReceipt(receiptDTO);
    }

    @Override
    public List<ReceiptDTO> getallReceiptbyLoanACC(String id, Date fromdate, Date todate) {
        return receiptDAO.getallReceiptbyLoanACC(id, fromdate, todate);
    }
}
