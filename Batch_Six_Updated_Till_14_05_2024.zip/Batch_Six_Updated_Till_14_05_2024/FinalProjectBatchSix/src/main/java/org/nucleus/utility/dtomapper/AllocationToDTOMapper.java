package org.nucleus.utility.dtomapper;

import org.nucleus.entity.permanent.Allocation;
import org.nucleus.dto.AllocationDTO;

public class AllocationToDTOMapper {

    public static AllocationDTO mapObjectToDTO(Allocation allocation){

        AllocationDTO allocationDTO = new AllocationDTO();
        LoanAccountDTOMapper loanAccountDTOMapper = new LoanAccountDTOMapper();

        allocationDTO.setAllocationId(allocation.getAllocationId());
        allocationDTO.setLoanAccount(loanAccountDTOMapper.mapObjectToDTO(allocation.getLoanAccount()));
        allocationDTO.setDepositDate(allocation.getDepositDate());
        allocationDTO.setPenaltyCharge(allocation.getPenaltyCharge());
        allocationDTO.setPenaltyDescription(allocation.getPenaltyDescription());
        allocationDTO.setInterestComponentReceived(allocation.getInterestComponentReceived());
        allocationDTO.setPrincipalComponentReceived(allocation.getPrincipalComponentReceived());

        return allocationDTO;

    }

}
