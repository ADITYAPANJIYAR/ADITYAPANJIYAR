package org.nucleus.controller.restcontroller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.nucleus.dto.RepayScheduleDTO;
import org.nucleus.dto.RescheduleResponseDTO;
import org.nucleus.entity.permanent.Customer;
import org.nucleus.entity.permanent.LoanApplication;
import org.nucleus.entity.permanent.RepaySchedule;
import org.nucleus.entity.temporary.PersonInfoTemp;
import org.nucleus.service.LoanApplicationService;
import org.nucleus.service.RepayScheduleService;
import org.nucleus.utility.dtomapper.RepayScheduleMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

@RestController
@RequestMapping("reschedule")
@PreAuthorize("hasRole('MAKER') or hasRole('CHECKER')")
public class RescheduleRestController {
    private final LoanApplicationService loanApplicationService;
    private final RepayScheduleService repayScheduleService;
    private List<RepayScheduleDTO> repayScheduleDTOS = null;
    private RepayScheduleDTO toRescheduleFrom = null;
    private String loanAccountNumber = null;
    public RescheduleRestController(LoanApplicationService loanApplicationService, RepayScheduleService repayScheduleService){
        this.loanApplicationService = loanApplicationService;
        this.repayScheduleService = repayScheduleService;
    }
    @GetMapping("/getCustomerNameByLoanAccountNumber")
    public ResponseEntity<String> getCustomerNameByLoanAccountNumber(@RequestParam String loanAccountNumber) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setTimeZone(TimeZone.getDefault());
        LoanApplication loanApplication = loanApplicationService.getApplicationByAccountNumber(loanAccountNumber);
        if(loanApplication != null){
            Customer customer = loanApplication.getCustomer();
            if(customer != null) {
                PersonInfoTemp personInfo = customer.getPersonInfoTemp();
                if(personInfo != null) {
                    this.loanAccountNumber = loanAccountNumber;
                    String jsonData = objectMapper.writeValueAsString(personInfo.getFullName());
                    return ResponseEntity.status(HttpStatus.OK).body(jsonData);
                }
            }
        }
        String jsonData = objectMapper.writeValueAsString("LoanAccountNumber Not Found");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(jsonData);
    }
    @GetMapping(value = "/getRescheduleResponse", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getRescheduleResponse(@RequestParam String loanAccountNumber) throws JsonProcessingException {
        LoanApplication loanApplication =loanApplicationService.getApplicationByAccountNumber(loanAccountNumber);
        repayScheduleDTOS = repayScheduleService.fetchRepaySchedule(loanApplication.getLoanApplicationId());
        LocalDate currentDate = LocalDate.now();
        for(int i = 0; i<repayScheduleDTOS.size()-1; i++){
            if(repayScheduleDTOS.get(i).getDueDate().toLocalDate().isAfter(currentDate)) {
                toRescheduleFrom = repayScheduleDTOS.get(i+1);
                break;
            }
        }
        if(toRescheduleFrom == null)
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cannot Reschedule the current repayment schedule");
        ObjectMapper objectMapper = new ObjectMapper();
        RescheduleResponseDTO response = new RescheduleResponseDTO();
        response.setProductCode(loanApplication.getLoanProduct().getProductCode());
        response.setEffectiveDate(toRescheduleFrom.getDueDate().toString());
        response.setCurrentDueDate(toRescheduleFrom.getDueDate().toLocalDate().getDayOfMonth());
        response.setCurrentInstallment(toRescheduleFrom.getInstallmentAmount());
        response.setCurrentTenure(loanApplication.getTenure());
        response.setTenureIn(loanApplication.getTenureIn());
        response.setFrequency(loanApplication.getTenureIn());
        response.setRate(toRescheduleFrom.getEffectiveInterestRate());
        String jsonData = objectMapper.writeValueAsString(response);
        return ResponseEntity.status(HttpStatus.OK).body(jsonData);
    }
    @GetMapping("/checkRepaySchedule")
    public ResponseEntity<String> checkRepaySchedule(@RequestParam String key, @RequestParam String value) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setTimeZone(TimeZone.getDefault());
        String jsonData = "";
        System.out.println("assxz " + key + " " + value);
        if("dueDate".equals(key) && Integer.parseInt(value)<29 && Integer.parseInt(value)>0){
            for(RepayScheduleDTO repayScheduleDTO : repayScheduleDTOS)
                if(repayScheduleDTO.getInstallmentNumber() >= toRescheduleFrom.getInstallmentNumber())
                    repayScheduleDTO.setDueDate(Date.valueOf(repayScheduleDTO.getDueDate().toLocalDate().withDayOfMonth(Integer.parseInt(value))));
            jsonData = objectMapper.writeValueAsString(repayScheduleDTOS);
        }
        else if("tenure".equals(key)){
            // to be implemented

            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Tenure Change Not Implemented Yet");
        }
        else if("installment".equals(key)){
            // to be implemented
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Installment Change Not Implemented Yet");
        }
        if("".equals(jsonData))
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Invalid Data Entered");
        return ResponseEntity.status(HttpStatus.OK).body(jsonData);
    }
    @PutMapping
    public ResponseEntity<String> updateRepaySchedule() throws JsonProcessingException {
        LoanApplication loanApplication = loanApplicationService.getApplicationByAccountNumber(loanAccountNumber);
        List<RepaySchedule> repaySchedules = new ArrayList<>();
        for(RepayScheduleDTO repayScheduleDTO : repayScheduleDTOS)
            repaySchedules.add(RepayScheduleMapper.convertToEntity(repayScheduleDTO));
        loanApplication.setRepaySchedules(repaySchedules);
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonData = "";
        if(loanApplicationService.updatePermanent(loanApplication)) {
            jsonData = objectMapper.writeValueAsString("Repay Updated Successfully");
            return ResponseEntity.status(HttpStatus.OK).body(jsonData);
        }
        jsonData = objectMapper.writeValueAsString("Repay Does Not Updated");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(jsonData);
    }
}
