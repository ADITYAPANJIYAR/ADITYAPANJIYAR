package org.nucleus.exception;

public class RepaymentPolicyCodeDuplicationExcaption extends RuntimeException{
    public RepaymentPolicyCodeDuplicationExcaption(String message)
    {
        super(message);
    }
}
