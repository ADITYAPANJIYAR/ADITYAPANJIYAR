package org.nucleus.controller;

import org.nucleus.dto.CountryDTO;
import org.nucleus.service.address.CountryService;
import org.nucleus.service.address.CountryTempService;
import org.nucleus.utility.enums.RecordStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

        /****
         Unzala
         *****/

@Controller
@RequestMapping("maker/")
@PreAuthorize("hasRole('MAKER')")
public class CountryMakerController {
    private final CountryTempService countryTempService;
    private final CountryService countryService;
    @Autowired
    public CountryMakerController(CountryTempService countryTempService , CountryService countryService){
        this.countryTempService=countryTempService;
        this.countryService = countryService;

    }
    @GetMapping("country-form")
    public String showCountryForm(Model model){
        model.addAttribute("countryDto" ,new CountryDTO());
        return "country-form";
    }

    //create new country
    @PostMapping("new-country")
    public ModelAndView createCountry(@ModelAttribute("countryDto") CountryDTO countryDTO,
                                      @RequestParam(name = "action", required = false)
                                      String action){
        ModelAndView mv = new ModelAndView();

        if("cancel".equalsIgnoreCase(action)){
            mv.setViewName("redirect:/maker/country-form");
            return mv;
        }

        String message = countryTempService.saveCountry(countryDTO , action);
        mv.addObject("message" , message);
        mv.setViewName("country-form");
        return mv;
    }

    //display countries to the maker
    @GetMapping("show-country-list")
    public ModelAndView displayCountriesList(Model model){

        List<CountryDTO> countryDTOList = countryTempService.getAllCountries();
        List<CountryDTO> countryDTOS = countryService.getAllCountries();

        ModelAndView mv = new ModelAndView();

        //list of countries from temporary table
        mv.addObject("tempCountries", countryDTOList);

        //list of countries from permanent table
        mv.addObject("permCountries", countryDTOS);
        mv.setViewName("maker-country-list");

        return mv;
    }

    //delete country
    @PostMapping("/deleteCountry/{id}")
    public ModelAndView deleteCountry(@PathVariable("id") Integer id) {
        ModelAndView mv = new ModelAndView();

        String message = countryTempService.deleteCountry(id);

        mv.addObject("message" , message);
        mv.setViewName("redirect:/maker/show-country-list");
        return mv;
    }

    //display update country form
    @GetMapping("show-update-country-form")
    public String showUpdateCountryForm(@RequestParam(name= "id", required = false ) Integer id , @RequestParam(name="status" , required = false) String recordStatus,  Model model){
        if(RecordStatus.valueOf(recordStatus)==RecordStatus.A){

            CountryDTO countryDTO = countryService.getCountryById(id);

            model.addAttribute("countryDTO" , countryDTO);
        }
        if(RecordStatus.valueOf(recordStatus)==RecordStatus.N || RecordStatus.valueOf(recordStatus)==RecordStatus.M){
            CountryDTO countryDTO = countryTempService.getCountryById(id);
            model.addAttribute("countryDTO", countryDTO);
        }
        return "update-country-form";
    }

    //submit updated country
    @PostMapping("edit-country")
    public String updateCountry(@ModelAttribute("countryDTO")CountryDTO countryDTO, String action, Model model){
        System.out.println(countryDTO);
        System.out.println(countryDTO.getMetaData().getRecordStatus());
        String message="";
        if("save".equalsIgnoreCase(action)){
            message = countryTempService.updateCountryForm(countryDTO);
        }
        if("cancel".equalsIgnoreCase(action)){
            return "redirect:/maker/show-update-country-form";
        }
        model.addAttribute("countryDto" , countryDTO);

        model.addAttribute("message", message);
        return "redirect:show-country-list";
    }
}
