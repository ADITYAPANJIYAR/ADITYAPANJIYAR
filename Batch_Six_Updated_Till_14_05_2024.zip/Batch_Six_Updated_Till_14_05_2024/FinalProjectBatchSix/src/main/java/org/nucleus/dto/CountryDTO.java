package org.nucleus.dto;


import org.nucleus.entity.meta.TempMetaData;
import lombok.Data;

@Data
public class CountryDTO {

    private Integer id;
    private String countryGroup;
    private String countryName;
    private Integer countryIsdCode;
    private String countryIsoCode;
    private String nationality;
    private String region;
    private String status;
    private TempMetaData metaData;

    public CountryDTO(){
        this.metaData = new TempMetaData();
    }
    public TempMetaData getMetaData() {
        return metaData;
    }

    public void setMetaData(TempMetaData metaData) {
        this.metaData = metaData;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCountryGroup() {
        return countryGroup;
    }

    public void setCountryGroup(String countryGroup) {
        this.countryGroup = countryGroup;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public Integer getCountryIsdCode() {
        return countryIsdCode;
    }

    public void setCountryIsdCode(Integer countryIsdCode) {
        this.countryIsdCode = countryIsdCode;
    }

    public String getCountryIsoCode() {
        return countryIsoCode;
    }

    public void setCountryIsoCode(String countryIsoCode) {
        this.countryIsoCode = countryIsoCode;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Country{" +
                "id"+ id + '\''+
                "countryGroup='" + countryGroup + '\'' +
                ", countryName='" + countryName + '\'' +
                ", countryIsdCode=" + countryIsdCode +
                ", countryIsoCode='" + countryIsoCode + '\'' +
                ", nationality='" + nationality + '\'' +
                ", region='" + region + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
