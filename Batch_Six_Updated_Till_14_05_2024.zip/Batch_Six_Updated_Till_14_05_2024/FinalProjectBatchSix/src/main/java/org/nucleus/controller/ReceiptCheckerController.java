package org.nucleus.controller;


import org.nucleus.dto.ReceiptDTO;
import org.nucleus.entity.meta.TempMetaData;
import org.nucleus.service.ReceiptService;
import org.nucleus.service.ReceiptServiceTemp;
import org.nucleus.utility.OldDateEditor;
import org.nucleus.utility.enums.RecordStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/checker")
@PreAuthorize("hasRole('CHECKER')")
public class ReceiptCheckerController {
    @Autowired
    ReceiptService receiptService;
    @Autowired
    ReceiptServiceTemp receiptServiceTemp;

    private static ReceiptDTO receiptDTO12;

   private static Date [] dateArray = {null,null};

    @GetMapping("receipt")
    public String showReceivableForm(Model model) {  // show jsp form to search receivablePayable-id
        model.addAttribute("receiptChecker", new ReceiptDTO());
        return "forward:../views/receipt-checker-final.jsp";
    }

    @InitBinder
    public void bind(WebDataBinder binder) {
        binder.registerCustomEditor(Date.class, "paymentDate", new OldDateEditor());
    }

    @RequestMapping("receipt-Search")
    public ModelAndView handelReceivableSearch(@ModelAttribute ReceiptDTO receiptDTO,
                                               @RequestParam("dueDate") Date dueDate,
                                               @RequestParam("fromDate") Date fromDate,
                                               Model model) {  //show List of Receipt on given receivablePayable-id
        ModelAndView modelAndView = new ModelAndView("receipt-checker-final");
        if(receiptDTO.getReceivablePayable() != null){
            System.out.println("234567890------------>"+receiptDTO);
            receiptDTO12 = receiptDTO;
            System.out.println("123456---------------->"+receiptDTO12);
        }
        if(receiptDTO.getReceivablePayable() == null){
            receiptDTO = receiptDTO12;
        }
        modelAndView.addObject("receiptChecker", receiptDTO);

        if(dueDate == null){
            dueDate = dateArray[0];
        }
        else{
            dateArray[0] = dueDate;
        }
        if(fromDate == null){
            fromDate = dateArray[1];
        }
        else{
            dateArray[1] = fromDate;
        }
        if (receiptDTO.getReceivablePayable().getReceivablePayableId() != null) {
            List<ReceiptDTO> receipctDTOList = receiptServiceTemp.getListReceiptTempById(receiptDTO.getReceivablePayable().getReceivablePayableId());  //getList
            if (!receipctDTOList.isEmpty()) {

                List<ReceiptDTO> filteredReceiptList =
                        receipctDTOList
                                .stream()
                                .filter(receipt -> receipt.getTransactionDate().compareTo(dateArray[1]) >= 0
                                        && receipt.getTransactionDate().compareTo(dateArray[0]) <= 0)
                                .collect(Collectors.toList());

                if (!filteredReceiptList.isEmpty()) {
                    model.addAttribute("receiptList", filteredReceiptList);
                    receiptDTO.setLoanAccountNumber(filteredReceiptList.get(0).getLoanAccountNumber());
                    TempMetaData tempMetaData = filteredReceiptList.get(0).getTempMetaData();
                    receiptDTO.setTempMetaData(tempMetaData);
                    model.addAttribute("successMessage", "Receivable records has been successfully fetched.click cancel to Go back");
                } else {
                    model.addAttribute("errorMessage", "No Receipts found between the provided due date and from date. Please ensure the date is correct and try again.");
                }
            } else {
                model.addAttribute("errorMessage", "Failed to fetch data for the provided Receivable Payable Id. Please ensure the ID is correct and try again.");
            }
        } else {
            model.addAttribute("errorMessage", "Failed to fetch data for the provided Receivable Payable Id. Please ensure the ID is correct and try again.");
        }
        return modelAndView;
    }

    @GetMapping("/approve-Receipt/{receiptId}")
    public String approveReceivable(@PathVariable String receiptId,
                                          @ModelAttribute ReceiptDTO receiptDTO,
                                          Model model) {
        //Model modelAndView = new ModelAndView("redirect:/checker/receipt-Search?fromDate="+dateArray[1]+"&dueDate="+dateArray[0]);
        model.addAttribute("receiptChecker", receiptDTO);

        if (receiptId != null) {
            ReceiptDTO receiptDTO1 = receiptServiceTemp.getReceiptTempById(Long.valueOf(receiptId)); //Fetch receiptDTO from temp table given receipt-id
            if (receiptDTO1 != null) {
                TempMetaData tempMetaData = receiptDTO1.getTempMetaData(); //setMeta data
                tempMetaData.setAuthorizedDate(Date.valueOf(LocalDate.now()));
                tempMetaData.setRecordStatus(RecordStatus.A);
                Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                String username = authentication.getName();
                tempMetaData.setAuthorizedBy(username);
                receiptDTO1.setTempMetaData(tempMetaData);
                boolean flag = receiptService.createReceiptDTO(receiptDTO1); //insert into master table
                if (flag) {
                    boolean flagSubmit = receiptServiceTemp.deleteReceiptTemp(receiptDTO1); //Delete into temporary table of Receipt
                    if (flagSubmit) {
                        model.addAttribute("successMessage", "Receivable records has been successfully approved.click back to Go back");
                    } else {
                        model.addAttribute("errorMessage", "Receivable records is not approved!.Error while Inserting records in permanent table");
                    }
                } else {
                    model.addAttribute("errorMessage", "Receivable records is not delete!.Error while deleting records in temporary table");
                }
            } else {
                model.addAttribute("errorMessage", "Receivable records is not fetched!.Error while fetching records in temporary table");
            }
        } else {
            model.addAttribute("errorMessage", "Failed to fetch data for the provided Receivable Payable Id. Please ensure the ID is correct and try again.");
        }
        return "redirect:/checker/receipt-Search?fromDate="+dateArray[1]+"&dueDate="+dateArray[0];
    }
    @GetMapping("/reject-Receipt/{receiptId}")
    public String rejectReceivable(@PathVariable String receiptId,
                                         @ModelAttribute ReceiptDTO receiptDTO,
                                         Model model) {

        model.addAttribute("receiptChecker", receiptDTO);
        if (receiptId != null) {
            ReceiptDTO receiptDTO1 = receiptServiceTemp.getReceiptTempById(Long.valueOf(receiptId)); //Fetch receiptDTO from temp table given receipt-id
            if (receiptDTO != null) {
                TempMetaData tempMetaData = receiptDTO1.getTempMetaData();  //Set Temp Data
                tempMetaData.setRecordStatus(RecordStatus.NR);
                receiptDTO1.setTempMetaData(tempMetaData);
                boolean flag = receiptServiceTemp.updateReceiptTemp(receiptDTO1); //Update in Receipt temp table
                if (flag) {
                    model.addAttribute("successMessage", "Receivable records has been successfully Rejected. click back to Go back");
                } else {
                    model.addAttribute("errorMessage", "Receivable records is not rejected.");
                }
            } else {
                model.addAttribute("errorMessage", "Receivable records is not fetched!.Error while fetching records in temporary table");
            }
        } else {
            model.addAttribute("errorMessage", "Failed to fetch data for the provided Receivable Payable Id. Please ensure the ID is correct and try again.");
        }
        return "redirect:/checker/receipt-Search?fromDate="+dateArray[1]+"&dueDate="+dateArray[0];
    }
}
