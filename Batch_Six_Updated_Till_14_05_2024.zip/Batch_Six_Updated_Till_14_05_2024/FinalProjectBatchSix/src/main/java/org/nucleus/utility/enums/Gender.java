package org.nucleus.utility.enums;

public enum Gender {
    MALE, FEMALE,OTHER
}
