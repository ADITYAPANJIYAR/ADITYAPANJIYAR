package org.nucleus.utility.enums;

public enum ReceivablePayableStatus {
    PAID, PENDING
}
