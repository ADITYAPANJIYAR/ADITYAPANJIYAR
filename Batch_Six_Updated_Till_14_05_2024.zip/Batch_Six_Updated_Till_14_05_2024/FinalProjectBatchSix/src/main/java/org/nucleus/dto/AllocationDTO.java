package org.nucleus.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.sql.Date;

public class AllocationDTO {

    private Long allocationId;
    private LoanAccountDTO loanAccountDTO;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date depositDate;
    private Double interestComponentReceived;
    private Double principalComponentReceived;
    private Double penaltyCharge;
    private String penaltyDescription;

    public Long getAllocationId() {
        return allocationId;
    }

    public void setAllocationId(Long allocationId) {
        this.allocationId = allocationId;
    }

    public LoanAccountDTO getLoanAccount() {
        return loanAccountDTO;
    }

    public void setLoanAccount(LoanAccountDTO loanAccountDTO) {
        this.loanAccountDTO = loanAccountDTO;
    }

    public Date getDepositDate() {
        return depositDate;
    }

    public void setDepositDate(Date depositDate) {
        this.depositDate = depositDate;
    }

    public Double getInterestComponentReceived() {
        return interestComponentReceived;
    }

    public void setInterestComponentReceived(Double interestComponentReceived) {
        this.interestComponentReceived = interestComponentReceived;
    }

    public Double getPrincipalComponentReceived() {
        return principalComponentReceived;
    }

    public void setPrincipalComponentReceived(Double principalComponentReceived) {
        this.principalComponentReceived = principalComponentReceived;
    }

    public Double getPenaltyCharge() {
        return penaltyCharge;
    }

    public void setPenaltyCharge(Double penaltyCharge) {
        this.penaltyCharge = penaltyCharge;
    }

    public String getPenaltyDescription() {
        return penaltyDescription;
    }

    public void setPenaltyDescription(String penaltyDescription) {
        this.penaltyDescription = penaltyDescription;
    }

    @Override
    public String toString() {
        return "Allocation{" +
                "allocationId=" + allocationId +
                ", loanAccount=" + loanAccountDTO +
                ", depositDate=" + depositDate +
                ", interestComponentReceived=" + interestComponentReceived +
                ", principalComponentReceived=" + principalComponentReceived +
                ", penaltyCharge=" + penaltyCharge +
                ", penaltyDescription='" + penaltyDescription + '\'' +
                '}';
    }

}
