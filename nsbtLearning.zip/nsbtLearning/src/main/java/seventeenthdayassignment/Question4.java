package seventeenthdayassignment;

public class Question4 {
}
