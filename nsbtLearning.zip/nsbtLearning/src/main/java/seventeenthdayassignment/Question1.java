package seventeenthdayassignment;

import java.io.*;

public class Question1 {
    public static void main(String[] args) {
        File file1=new File("MyFile.txt");
        try {
            FileWriter fileWriter=new FileWriter(file1,true);
            fileWriter.write(" file create by file writer");
            System.out.println("File created and content written successfully.");
            fileWriter.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        try {
            FileOutputStream fileOutputStream=new FileOutputStream("MyFileOutputStream.txt");
            fileOutputStream.write("file create by FileOutputStream".getBytes());
            System.out.println("File created and content written successfully.");
            fileOutputStream.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
