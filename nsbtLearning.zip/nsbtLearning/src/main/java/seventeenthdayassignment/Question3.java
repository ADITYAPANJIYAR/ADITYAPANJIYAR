package seventeenthdayassignment;

public class Question3 {
    public static void main(String[] args) {

    }
}
