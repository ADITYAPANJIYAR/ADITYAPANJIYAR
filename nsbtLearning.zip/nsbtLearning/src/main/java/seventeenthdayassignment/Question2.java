package seventeenthdayassignment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Question2 {
    public static void main(String[] args) {
        try {
            FileReader fileReader=new FileReader("MyFile.txt");
            System.out.println("Reading content using FileReader:");
            int ch;
            while ((ch=fileReader.read())!=-1){
                System.out.println((char) ch);
            }
            fileReader.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        FileInputStream fileInputStream;
        {
            try {
                fileInputStream = new FileInputStream("MyFile.txt");
                System.out.println("Reading content using FileInputStream:");
                int ch;
                while ((ch=fileInputStream.read())!=-1){
                    System.out.println((char) ch);
                }
                fileInputStream.close();
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

}
