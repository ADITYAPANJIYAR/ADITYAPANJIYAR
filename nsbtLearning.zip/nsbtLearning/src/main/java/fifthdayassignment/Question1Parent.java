package fifthdayassignment;

public class Question1Parent {
    public void print(){
        System.out.println("This is Parent class");
    }

    public Question1Parent() {
        System.out.println("Question1Parent constructor called");
    }
}
