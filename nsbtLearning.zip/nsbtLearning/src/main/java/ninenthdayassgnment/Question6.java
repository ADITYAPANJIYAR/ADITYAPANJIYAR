package ninenthdayassgnment;

import java.util.Comparator;

public class Question6 {
    Comparator
}
