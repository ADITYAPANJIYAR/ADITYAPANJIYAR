package ninenthdayassgnment;

import eighthdayassignment.question2.customer.Customer;

@FunctionalInterface
public interface CalculateIncomeAndAge {
    boolean calculateIncome(Customer customer);
}
