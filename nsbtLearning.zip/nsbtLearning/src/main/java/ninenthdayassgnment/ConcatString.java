package ninenthdayassgnment;
@FunctionalInterface
public interface ConcatString {
    String concat(String s1, String s2);
}
