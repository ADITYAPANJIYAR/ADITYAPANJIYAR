package fifteenthdayassignment;
public class Question12 {
    public static void main(String[] args) {
        //
    }
}