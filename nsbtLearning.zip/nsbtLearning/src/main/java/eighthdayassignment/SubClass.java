package eighthdayassignment;

public class SubClass extends MyClass {
    public static void main(String[] args) {
        MyClass myClass=new MyClass();
        myClass.publicMethod();
        myClass.defaultMethod();
        myClass.protectedMethod();
    }
}
