package eighthdayassignment;

public class MyClass {
    private void privateMethod(){

    }
    void defaultMethod(){//default

    }
    protected void protectedMethod(){

    }
    public void publicMethod(){

    }
}
