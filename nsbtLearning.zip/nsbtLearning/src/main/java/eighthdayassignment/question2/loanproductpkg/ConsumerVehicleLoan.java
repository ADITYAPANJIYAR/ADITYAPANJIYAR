package eighthdayassignment.question2.loanproductpkg;

import fifthdayassignment.LoanProduct;

enum AssetCategory{
    CAR, SCOOTER, BIKE

}

enum AssetVariant{
    PETROL, DIESEL, CNG
}
public class ConsumerVehicleLoan extends LoanProduct {

    AssetCategory assetCategory;
    AssetVariant assetVariant;
    private String assetModel;
    private String manufacturer;
    private int yearOfManufacture;
    private double assetsCost;
    private double downPayment;
    @Override
    public double ltvCalculateAsPerCollateralType(double loanAmountAsked) {
        System.out.println("ConsumerVehicleLoan called");
        return (loanAmountAsked/assetsCost);
    }

    //constructors...
    public ConsumerVehicleLoan(double assetsCost) {
        this.assetsCost=assetsCost;
    }
    public ConsumerVehicleLoan(String loanProductCode, String loanProductName, String assetModel, String manufacturer) {
        super(loanProductCode, loanProductName);
        this.assetModel = assetModel;
        this.manufacturer = manufacturer;
    }

    //getter and setters...

    public AssetCategory getAssetCategory() {
        return assetCategory;
    }

    public void setAssetCategory(AssetCategory assetCategory) {
        this.assetCategory = assetCategory;
    }

    public AssetVariant getAssetVariant() {
        return assetVariant;
    }

    public void setAssetVariant(AssetVariant assetVariant) {
        this.assetVariant = assetVariant;
    }

    public String getAssetModel() {
        return assetModel;
    }

    public void setAssetModel(String assetModel) {
        this.assetModel = assetModel;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public int getYearOfManufacture() {
        return yearOfManufacture;
    }

    public void setYearOfManufacture(int yearOfManufacture) {
        this.yearOfManufacture = yearOfManufacture;
    }

    public double getAssetsCost() {
        return assetsCost;
    }

    public void setAssetsCost(double assetsCost) {
        this.assetsCost = assetsCost;
    }

    public double getDownPayment() {
        return downPayment;
    }

    public void setDownPayment(double downPayment) {
        this.downPayment = downPayment;
    }
}
