package eighthdayassignment.question2.enumpkg;

public enum AssetCategory {
    CAR, SCOOTER, BIKE

}
