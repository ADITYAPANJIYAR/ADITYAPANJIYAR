package eighthdayassignment.question2.enumpkg;

public enum EmiStatus {
    PENDING,
    ACTIVE,
    COMPLETED;
}
