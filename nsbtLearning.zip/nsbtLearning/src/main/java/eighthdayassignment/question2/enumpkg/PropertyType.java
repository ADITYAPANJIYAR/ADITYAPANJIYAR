package eighthdayassignment.question2.enumpkg;

public enum PropertyType {
    SHOP, OFFICE, FLAT, VILLA
}
