package eighthdayassignment.question2.enumpkg;

public enum PropertyOwnership {
    FREEHOLD, LEASE
}
