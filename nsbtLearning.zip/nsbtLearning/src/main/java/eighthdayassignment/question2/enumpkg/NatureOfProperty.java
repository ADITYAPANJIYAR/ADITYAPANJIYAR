package eighthdayassignment.question2.enumpkg;

public enum NatureOfProperty {
    RESIDENTIAL, COMMERCIAL
}
