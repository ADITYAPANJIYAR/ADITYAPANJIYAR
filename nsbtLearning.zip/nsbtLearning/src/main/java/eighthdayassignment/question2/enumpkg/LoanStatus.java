package eighthdayassignment.question2.enumpkg;

public enum LoanStatus {
    APPROVE,
    PENDING,
    REJECTED,
    ACTIVE,
    CLOSED;


}
