package eighthdayassignment;

public interface Question3 {
    boolean hasNext();
    Object next();
    void remove();

}
