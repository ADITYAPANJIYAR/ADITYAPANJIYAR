package thirteenthdayassignment;

import eighthdayassignment.question2.enumpkg.EmiStatus;

import java.time.LocalDate;

public class RepaymentSchedule {
    double emiAmount;
    LocalDate emiDueDate;
    EmiStatus status;
    double principalComponent;
    double interestAmount;
    double balancePrincipalComponent;
    double penaltyCharges;

}
