package seventhdayassignment;

public class Question2c {
    public static void main(String[] args) {

        methodA();
    }
    public static void methodA(){
//        throw new ClassNotFoundException(); will always show error
    }
}
