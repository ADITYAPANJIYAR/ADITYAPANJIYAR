package tenthdayassignment;

// SingletonEnum.java
public enum SingletonEnum {
    INSTANCE;

    public void someMethod() {
    }
}

