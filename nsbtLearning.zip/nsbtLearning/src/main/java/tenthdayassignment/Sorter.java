package tenthdayassignment;

public interface Sorter {
    int[] sort(int[] numbers);
}