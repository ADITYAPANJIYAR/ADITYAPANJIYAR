package tenthdayassignment;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class NumberSorter {
    public List<Integer> sort(List<Integer>number){
        Collections.sort(number);
        return number;
    }
}
