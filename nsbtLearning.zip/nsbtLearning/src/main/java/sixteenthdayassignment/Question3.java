package sixteenthdayassignment;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Question3 {
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        int numThreads = 4; // Number of threads
        int range = 10000; // Range of numbers to check
        int numbersPerThread = range / numThreads; // Numbers each thread will process

        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        final DivisorClass[] divisors = new DivisorClass[numThreads]; // Declare divisors as final

        // Execute tasks using thread pool
        for (int i = 0; i < numThreads; i++) {
            divisors[i] = new DivisorClass(); // Initialize the divisor object for each thread
            final int start = i * numbersPerThread + 1;
            final int end = (i + 1) * numbersPerThread;
            final DivisorClass divisor = divisors[i]; // Intermediate final variable
            executor.submit(() -> divisor.divisorFinder(end)); // Use the intermediate variable
        }

        // Shutdown executor
        executor.shutdown();

        // Wait for all tasks to complete
        while (!executor.isTerminated()) {
            // Do nothing, just wait
        }

        // Find the maximum divisor among all threads
        DivisorClass maxDivisor = new DivisorClass();
        for (DivisorClass divisor : divisors) {
            if (divisor.getMaximum().get() > maxDivisor.getMaximum().get()) {
                maxDivisor = divisor;
            }
        }

        long endTime=System.currentTimeMillis();
        System.out.println("Time is "+(endTime-startTime));
        System.out.println(maxDivisor.getMaximumDivisor());
        System.out.println(maxDivisor.getMaximum());
    }
}
