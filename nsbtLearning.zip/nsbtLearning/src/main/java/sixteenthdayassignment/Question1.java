package sixteenthdayassignment;

public class Question1 {
    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        DivisorClass divisorClass1=new DivisorClass();
        divisorClass1.divisorFinder(10000);
        System.out.println(divisorClass1.getMaximumDivisor());
        System.out.println(divisorClass1.getMaximum());
        long endTime = System.currentTimeMillis();
        System.out.println("Time is "+(endTime-startTime));
    }
}


