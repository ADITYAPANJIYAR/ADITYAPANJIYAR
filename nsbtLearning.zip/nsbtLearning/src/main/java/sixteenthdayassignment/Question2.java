package sixteenthdayassignment;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Question2 {
    public static void main(String[] args) {
        int numThreads = 4; // Number of threads
        int range = 10000; // Range of numbers to check
        int numbersPerThread = range / numThreads; // Numbers each thread will process

        DivisorClass[] divisors = new DivisorClass[numThreads];

        // Create threads
        Thread[] threads = new Thread[numThreads];
        for (int i = 0; i < numThreads; i++) {
            divisors[i] = new DivisorClass();
            final int start = i * numbersPerThread + 1;
            final int end = (i + 1) * numbersPerThread;
            threads[i] = new Thread(() -> divisors[start - 1].divisorFinder(end));
            threads[i].start();
        }

        // Wait for all threads to finish
        try {
            for (Thread thread : threads) {
                thread.join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Find the maximum divisor among all threads
        DivisorClass maxDivisor = new DivisorClass();
        for (DivisorClass divisor : divisors) {
            if (divisor.getMaximum().get() > maxDivisor.getMaximum().get()) {
                maxDivisor = divisor;
            }
        }

        System.out.println(maxDivisor.getMaximumDivisor());
        System.out.println(maxDivisor.getMaximum());
    }
}

