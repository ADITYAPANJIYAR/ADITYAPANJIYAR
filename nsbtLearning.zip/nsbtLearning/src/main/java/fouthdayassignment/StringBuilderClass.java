package fouthdayassignment;

public class StringBuilderClass {
    public static void main(String[] args) {
        StringBuilder stringBuilder=new StringBuilder("reverse");
        stringBuilder.reverse();
        System.out.println(stringBuilder);
    }
}
