package fouthdayassignment;

public class StringBufferClass {
    public static void main(String[] args) {
        StringBuffer stringBuffer=new StringBuffer("qwerty");
        stringBuffer.reverse();
        System.out.println(stringBuffer);
    }


}
