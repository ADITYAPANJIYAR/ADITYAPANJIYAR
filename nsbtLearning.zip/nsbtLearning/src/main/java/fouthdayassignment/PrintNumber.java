package fouthdayassignment;

public class PrintNumber {
    public static void print(int a){
        System.out.println(a);
    }
    public static void print(float b){
        System.out.println(b);
    }
    public static void print(double c){
        System.out.println(c);
    }
}
