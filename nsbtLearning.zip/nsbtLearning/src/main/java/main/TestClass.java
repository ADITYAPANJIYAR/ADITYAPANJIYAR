package main;

import eighthdayassignment.MyClass;

public class TestClass{
    public static void main(String[] args) {
        MyClass myClass=new MyClass();
        myClass.publicMethod();
    }

}
