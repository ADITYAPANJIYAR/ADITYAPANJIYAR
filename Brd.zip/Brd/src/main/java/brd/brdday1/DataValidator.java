package brd.brdday1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class DataValidator {
    public static boolean isDataType(Object value, String dataType) {
        try {
            switch (dataType) {
                case "Numeric":
                    Double.parseDouble(value.toString());
                    break;
                case "Integer":
                    Integer.parseInt(value.toString());
                    break;
                case "String":
                    String.valueOf(value);
                    break;
                case "Boolean":
                    String stringValue = value.toString().toLowerCase();
                    if (stringValue.equals("true") || stringValue.equals("false")) {
                        return true;
                    } else {
                        return false;
                    }
                default:
                    return false; // Default case for unsupported data types
            }
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    // Data Length Validation
    public static <T> boolean isValidLength(T value, int maxLength) {
        return String.valueOf(value).length() <= maxLength;
    }

    // Special Characters Validation
    public static boolean hasSpecialCharacters(String value, String specialCharacters) {
        for (char c : specialCharacters.toCharArray()) {
            if (value.contains(String.valueOf(c))) {
                return true;
            }
        }
        return false;

    }

    // Domain Value Validation
    public static boolean isValidDomainValue(String value, String[] validValues) {
        for (String validValue : validValues) {
            if (value.equalsIgnoreCase(validValue)) {
                return true;
            }
        }
        return false;
    }

    // Format Validation
    public static boolean isValidFormat(String value, String format) {
        return value.matches(format);
    }

    // Email Validation
    public static boolean isValidEmail(String email) {
        // Regular expression to validate email
        String emailCheck = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        Pattern pattern = Pattern.compile(emailCheck);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
}