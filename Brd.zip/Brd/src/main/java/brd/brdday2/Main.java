package brd.brdday2;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class Main {
    private static final Logger log= LogManager.getLogger(Main.class);
    public static void main(String[] args) {
        String fileName="/Users/adityapanjiyar/Downloads/IdeaProjects/Brd/src/main/resources/File1.txt";
        List<String> finalList=new ArrayList<>();
        finalList=DataValidator2.addList(fileName);

//        for (String element: fianlList) {
//            log.info(element);
//        }
//        log.info(finalList.get(1));
//        DataValidator2.isValidPhoneNumber(finalList.get(1).substring(74,84));
//        DataValidator2.isMandatoryFilled(finalList);
        DataValidator2.emailValidator("wipro@gmail.com");


    }
}
