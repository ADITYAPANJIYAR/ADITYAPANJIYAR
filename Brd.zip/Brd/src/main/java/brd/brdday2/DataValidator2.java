package brd.brdday2;

import brd.brdday1.DataValidator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import static brd.brdday1.DataValidator.*;

public class DataValidator2 {
    private static final Logger log= LogManager.getLogger(DataValidator2.class);
    public static List<String> addList(String filename) {
        List<String> dataList=new ArrayList<>();
        try(FileReader fileReader=new FileReader(filename)) {
            BufferedReader bufferedReader=new BufferedReader(fileReader);
            String s;
            while ((s=bufferedReader.readLine())!=null){
                dataList.add(s);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }

        List<String> fianlList=new ArrayList<>();
        for (int i = 0; i < dataList.size(); i++) {
            fianlList.add(removeSign(dataList.get(i)).toString());
        }

//        for (String element: fianlList) {
//            log.info(element);
//        }
        return fianlList;
    }

    public static List<String> removeSign(String line){
        line=line.replaceAll("~","~ ");
        String[] finalData=line.split("~");
        for (int i = 0; i < finalData.length; i++) {
            if (finalData[i].equals(" ")){
                finalData[i]="null";
                finalData[i]=finalData[i].trim();
            }
        }
        List<String> list=List.of(finalData);
        return list;

    }

    public static boolean isValidRecordLength(List<String> values) {
        return isValidLength(values.get(0), 10) &&
                isValidLength(values.get(1), 30) &&
                isValidLength(values.get(2), 100) &&
                isValidLength(values.get(3), 100) &&
                isValidLength(values.get(4), 6) &&
                isValidLength(values.get(5), 100) &&
                isValidLength(values.get(6), 20) &&
                isValidLength(values.get(7), 100) &&
                isValidLength(values.get(8), 1) &&
                isValidLength(values.get(9), 1) &&
                isValidLength(values.get(11), 30) &&
                isValidLength(values.get(13), 30) &&
                isValidLength(values.get(15), 30);
    }

    public static boolean emailValidator(String email) {
        return isValidEmail(email);
    }
    public static boolean isValidPhoneNumber(String phoneNumber) {
        return isValidLength(phoneNumber, 10) && DataValidator.isDataType(phoneNumber, "Numeric");
    }
    

    public static boolean isMandatoryFilled(List<String> values) {
        int[] mandatoryIndices = {0, 1, 2, 4, 5, 7, 8, 9, 10, 11, 12};
        for (int index : mandatoryIndices) {
            if (values.get(index) == null || values.get(index).isEmpty()) {
                log.info(String.format("Error at: %s", values.get(index)));
                return false;
            }
        }
        return true;
    }

}
